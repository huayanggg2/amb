package cmd

import (
	"fmt"
	"os"
	"strings"

	. "acos-magic-box/common"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var (
	// Used for flags.
	cfgFile string

	RootCmd = &cobra.Command{
		Use:        "amb",
		Short:      "ACOS Magic Box",
		Long:       `ACOS自助排查工具，可以快速进行一系列操作。`,
		SuggestFor: []string{"debug", "k8s"},
		Example:    examples(),
		PreRun: func(cmd *cobra.Command, args []string) {
			SetCommonFlags(cmd)
		},
	}
)

type CmdUsage struct {
	Name string
	Cmd  string
}

func examples() string {
	var list []CmdUsage
	list = append(list, CmdUsage{Name: "排查Java无数据", Cmd: "amb debug app --pid <应用ID>"})
	list = append(list, CmdUsage{Name: "查询租户列表", Cmd: "amb app list"})
	list = append(list, CmdUsage{Name: "查询租户列表", Cmd: "amb tenant list"})

	var temp []string
	for _, l := range list {
		formatStr := fmt.Sprintf("%-*s %-*s\n", 30, l.Name, 1, l.Cmd)
		temp = append(temp, formatStr)
	}
	return strings.Join(temp, "")
}

// Execute executes the root command.
func Execute() error {
	return RootCmd.Execute()
}

func init() {
	cobra.OnInitialize(initConfig)

	//RootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file (default is $HOME/.amb.yaml)")
	RootCmd.PersistentFlags().Bool("debug", false, "是否输出执行过程？")
	viper.BindPFlag("debug", RootCmd.PersistentFlags().Lookup("debug"))
	viper.SetDefault("debug", "false")

	// 子命令
	RootCmd.AddCommand(installAliasCmd)
}

var installAliasCmd = &cobra.Command{
	Use:     "install-aliases",
	Short:   "安装bash的aliases",
	Example: examples(),
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		CopyScriptToTemp("cnstack-aliases.sh")
		ExecCommandAndOutput("cp -r /tmp/cnstack-aliases.sh /root/cnstack-aliases.sh")
		ExecCommandAndOutput("echo 'source /root/cnstack-aliases.sh' >> .bashrc")
		PrintSuccess("安装成功，请执行 source /root/.bashrc 以便别名生效!")
	},
}

func initConfig() {
	if cfgFile != "" {
		// Use config file from the flag.
		viper.SetConfigFile(cfgFile)
	} else {
		// Find home directory.
		home, err := os.UserHomeDir()
		cobra.CheckErr(err)

		// Search config in home directory with name ".cobra" (without extension).
		viper.AddConfigPath(home)
		viper.SetConfigType("yaml")
		viper.SetConfigName(".amb")
	}

	viper.AutomaticEnv()

	if err := viper.ReadInConfig(); err == nil {
		fmt.Println("Using config file:", viper.ConfigFileUsed())
	}
}
