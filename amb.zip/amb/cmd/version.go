package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

func init() {
	RootCmd.AddCommand(versionCmd)
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print the version number of Amb",
	Long:  `All software has versions. This is Amb's`,
	Run: func(cmd *cobra.Command, args []string) {
		version := os.Getenv("VERSION")
		fmt.Println(version)
	},
}
