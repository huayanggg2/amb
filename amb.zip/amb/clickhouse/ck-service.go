package clickhouse

import (
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	errors "errors"
	"fmt"
	"strings"
)

func Query(database string, query string) (string, error) {
	output, err := ExecCommandAndOutput("kubectl -n acos exec -it chi-clickhouse-cluster-dtstack-0-0-0 -c clickhouse-cluster" +
		" -- /bin/bash -c \"clickhouse-client --password 'abc123' -d '" + database + "' -q \\\"" + query + "\\\"\"")
	if err != nil {
		PrintError(fmt.Sprintf("query clickhouse error: %s", err.Error()))
		return output, err
	}

	output = strings.Replace(output, "Unable to use a TTY - input is not a terminal or the right kind of file", "", -1)
	output = RemoveEmptyLines(output)

	return output, nil
}

type MetricsStatus struct {
	MetadataTs string
	RpcTs      string
}

func ExecQuery(databaseName string, tableName string, sql string) (string, error) {
	result, err := Query(databaseName, sql)

	if err != nil && strings.Contains(result, "UNKNOWN_TABLE") {
		return result, errors.New("数据库或表不存在：" + databaseName + "." + tableName)
	}
	return result, nil
}

// QueryMetadataLatestTime 从ClickHouse查询最后存储的监控数据
func QueryMetadataLatestTime(appId string, tenantId any) (MetricsStatus, error) {
	databaseName := fmt.Sprintf("distributed_%v", tenantId)
	tableName := "arms_metadata"
	var sql1 = fmt.Sprintf("select toDateTime(_at_timestamp_,'Asia/Shanghai') from %s where pid='%s' order by _at_timestamp_ desc limit 1", tableName, appId)
	metadataLatestTime, err := ExecQuery(databaseName, tableName, sql1)
	if err != nil {
		return MetricsStatus{}, err
	}
	metadataLatestTime = RemoveEnter(metadataLatestTime)
	if IsDebug {
		PrintSuccess(fmt.Sprintf("Query from ClickHouse: \n\tsql: %s\n[%s]", sql1, metadataLatestTime))
	}

	tableName = "arms_stat_span"
	var sql2 = fmt.Sprintf("select toDateTime(_at_timestamp_,'Asia/Shanghai') from %s where pid='%s' order by _at_timestamp_ desc limit 1", tableName, appId)
	rpcLatestTime, err := ExecQuery(databaseName, tableName, sql2)
	if err != nil {
		return MetricsStatus{}, err
	}
	rpcLatestTime = RemoveEnter(rpcLatestTime)
	if IsDebug {
		PrintSuccess(fmt.Sprintf("Query from ClickHouse: \n\tsql: %s\n[%s]", sql2, rpcLatestTime))
	}

	return MetricsStatus{
		MetadataTs: metadataLatestTime,
		RpcTs:      rpcLatestTime,
	}, nil
}

func QueryAppLogLatestTime(appId string, projectId string, tenantId any) string {
	var sql = fmt.Sprintf("select toDateTime(_at_timestamp_,'Asia/Shanghai') from \"%s\" where __pod_app_id__='%s' order by _at_timestamp_ desc limit 1", projectId, appId)

	querySqlFilePath := "/tmp/query.sql"
	WriteToFile(sql, querySqlFilePath)
	dbName := fmt.Sprintf("distributed_%v", tenantId)
	var ckCmd = `clickhouse-client --password 'abc123' -d '%s' < /tmp/query.sql`
	shellScript := fmt.Sprintf(ckCmd, dbName)

	CopyFileToPodV1(DefaultNamespace, "sts", "chi-clickhouse-cluster-dtstack-0-0-0", "clickhouse", querySqlFilePath, querySqlFilePath)

	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "clickhouse-cluster",
			Name:      "chi-clickhouse-cluster-dtstack-0-0-0",
		},
		Cmd: shellScript,
	}
	output, _ := ckPodCmd.Init().ExecCommandInPod()
	if IsDebug {
		PrintSuccess(output)
	}
	return output
}

// CheckTableExist 检查指定表是否存在
func CheckTableExist(database string, table string) bool {
	tables, _ := Query(database, "show tables;")
	return strings.Contains(tables, table)
}

// QueryFrontAppLatestTime 从ClickHouse查询最后存储的监控数据
func QueryFrontAppLatestTime(appId string, tenantId any) string {
	var sql1 = fmt.Sprintf("select toDateTime(_at_timestamp_,'Asia/Shanghai') from arms_frontend_log where pid='%s' order by _at_timestamp_ desc limit 1", appId)
	latestTime, _ := Query(fmt.Sprintf("distributed_%v", tenantId), sql1)
	latestTime = RemoveEnter(latestTime)
	if IsDebug {
		PrintSuccess(fmt.Sprintf("Query from ClickHouse: \n\tsql: %s\n[%s]", sql1, latestTime))
	}

	return latestTime
}
