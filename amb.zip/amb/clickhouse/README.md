# Clickhouse常用命令

## 通过service访问clickhouse查询数据

* 参考文档：https://clickhouse.com/docs/en/interfaces/http

```shell
echo 'SELECT 1' | curl 'http://default:abc123@clickhouse-cluster:8123/' -d @-
```