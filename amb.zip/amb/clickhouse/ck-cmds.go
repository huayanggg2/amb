package clickhouse

import (
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"acos-magic-box/replicate"
	"github.com/spf13/cobra"
	"os"
)

var rcNum int
var sdNum int

func init() {
	replicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	replicaCmd.MarkPersistentFlagRequired("rcNum")
	replicaCmd.PersistentFlags().IntVar(&sdNum, "sdNum", 1, "shard number")
	replicaCmd.MarkPersistentFlagRequired("sdNum")
	ckRootCmd.AddCommand(entryPodCmd)
	ckRootCmd.AddCommand(replicaCmd)
}

var entryPodCmd = &cobra.Command{
	Use:   "pod",
	Short: "进入ClickHouse的Pod交互模式",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		var ckPodCmd = &k8s.AmbPodExec{
			Meta: &k8s.AmbPod{
				Namespace: DefaultNamespace,
				Container: "clickhouse-cluster",
				Name:      "chi-clickhouse-cluster-dtstack-0-0-0",
			},
			Cmd: "clickhouse-client --password abc123",
		}
		ckPodCmd.Init().ExecCommand()
	},
}

var replicaCmd = &cobra.Command{
	Use:     "rc",
	Short:   "修改clickhouse分区数和副本数",
	Example: "amb ck rc --rcNum 1 --sdNum 1",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum < 1 || sdNum < 1 {
			PrintError("副本数或分区数不能小于1")
			os.Exit(0)
		}
		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/clickhouse-cluster/values.yaml")
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["shardsCount"] = sdNum
		replicate.WriteYaml(ap+"/charts/clickhouse-cluster/values.yaml", m)
		output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
	},
}
