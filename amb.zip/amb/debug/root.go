package debug

import (
	"acos-magic-box/cmd"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var DebugCmd = &cobra.Command{
	Use:   "debug",
	Short: "Debug常见问题",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

func init() {
	cmd.RootCmd.AddCommand(DebugCmd)
}
