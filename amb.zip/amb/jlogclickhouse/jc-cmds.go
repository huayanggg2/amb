package clickhouse

import (
	. "acos-magic-box/common"
	clickhouse "acos-magic-box/kafka"
	"acos-magic-box/replicate"
	"github.com/spf13/cobra"
	"os"
)

var rcNum int

func init() {
	jcreplicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	jcreplicaCmd.MarkPersistentFlagRequired("rcNum")

	jlogServerRootCmd.AddCommand(jcreplicaCmd)

	jsreplicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	jsreplicaCmd.MarkPersistentFlagRequired("rcNum")

	jlogServerRootCmd.AddCommand(jsreplicaCmd)
}

var jcreplicaCmd = &cobra.Command{
	Use:   "jcrc",
	Short: "修改jlogclickhouse副本数",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum < 1 {
			PrintError("副本数不能为偶数，且不小于1")
			os.Exit(0)
		}
		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/jlogclickhouse/values.yaml")
		PrintInfo(resourceProfile)
		currentReplicate := m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"].(int)
		if rcNum > currentReplicate {
			PrintStep("进行扩容jlogclickhouse操作！")
			brokers := clickhouse.ExecZkCmdInPod()
			PrintStep("扩容topic分区。。。")
			clickhouse.AddPartFromKfa(rcNum)
			PrintStep("重新分配。。。")
			clickhouse.RebalanceFromKfa(brokers)
		} else if rcNum < currentReplicate {
			PrintStep("进行缩容jlogclickhouse操作！")
		} else {
			PrintError("do nothing！")
			os.Exit(0)
		}
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		replicate.WriteYaml(ap+"/charts/jlogclickhouse/values.yaml", m)
		output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
	},
}
var jsreplicaCmd = &cobra.Command{
	Use:   "jsrc",
	Short: "修改jlogserver副本数",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum < 1 {
			PrintError("副本数不能为偶数，且不小于1")
			os.Exit(0)
		}

		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/jlogserver/values.yaml")
		currentReplicate := m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"].(int)
		if rcNum > currentReplicate {
			PrintStep("扩容jlogserver副本数！")
		} else if rcNum < currentReplicate {
			PrintStep("缩容jlogserver副本数！")
		} else {
			PrintStep("do nothing!")
			os.Exit(0)
		}
		PrintInfo(resourceProfile)
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		replicate.WriteYaml(ap+"/charts/jlogserver/values.yaml", m)
		output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
	},
}
