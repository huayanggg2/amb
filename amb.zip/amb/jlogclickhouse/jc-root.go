package clickhouse

import (
	"acos-magic-box/cmd"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var jlogServerRootCmd = &cobra.Command{
	Use:     "jlogservice",
	Aliases: []string{"jsc"},
	Short:   "jlogservice工具",
	Example: `
amb jsc jcrc --rcNum 2  // 修改jlogclickhouse副本数为 2
amb jsc jsrc --rcNum 2  // 修改jlogserver副本数为 2
`,
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

func init() {
	cmd.RootCmd.AddCommand(jlogServerRootCmd)
}
