package k8s

import (
	. "acos-magic-box/common"
	"fmt"
	"github.com/spf13/cobra"
)

type CrdWorkload struct {
	Name     string
	Kind     string
	Replicas int
}

var listAllRes = &cobra.Command{
	Use:     "all-resources",
	Aliases: []string{"allres"},
	Short:   "查询Namespace下所有资源",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		GetAllResources(k8sNamespace)
	},
}

func GetWorkloads(category string, ns string) []string {
	shellCmd := fmt.Sprintf("kubectl -n %s get %s | awk 'NR>1{print $1}'", ns, category)
	output, err := ExecCommandAndOutput(shellCmd)
	if err != nil {
		panic(err)
	}
	return SplitLines(output)
}

func GetPods(workloadName string, ns string) {
	shellCmd := fmt.Sprintf("kubectl -n %s get pod | grep -E '^%s' | awk '{print $1}'", ns, workloadName)
	_, err := ExecCommandAndOutput(shellCmd)
	if err != nil {
		panic(err)
	}
}

func GetAllResources(ns string) {
	shellCmd := fmt.Sprintf("kubectl api-resources --verbs=list --namespaced -o name | xargs -n 1 kubectl get --show-kind --ignore-not-found -n %s", ns)
	ExecCommand(shellCmd)
}

func PatchReplicasToZero(namespace string, kind string, name string) {
	PrintInfo("开始缩零: " + kind + "/" + name)
	_, err := PatchReplicas(namespace, kind, name, 0)
	if err == nil {
		PrintSuccess("已缩零: " + kind + "/" + name)
	}
}

func PatchReplicas(namespace string, kind string, name string, replicas int) (string, error) {
	PrintInfo(fmt.Sprintf("Patch Replicas: %s/%s, replicas: %v", kind, name, replicas))
	return ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s patch %s/%s --type merge -p '{\"spec\": {\"replicas\": %v}}'", namespace, kind, name, replicas))
}
