package k8s

import (
	. "acos-magic-box/common"
	"fmt"
	"os"
	"os/exec"
	"strings"
)

type AmbPod struct {
	Namespace string
	Name      string
	Container string
}

type AmbPodExec struct {
	Meta        *AmbPod
	ShellType   string
	Cmd         string
	PrintResult bool
}

func (pcmd *AmbPodExec) Init() *AmbPodExec {
	if pcmd.ShellType == "" {
		pcmd.ShellType = "/bin/bash"
	}
	return pcmd
}

// ExecCommandForPod 进入Pod交互模式
func (pcmd *AmbPodExec) ExecCommandForPod() {
	pcmd.Init()
	meta := pcmd.Meta
	fullCommand := fmt.Sprintf("kubectl -n %s exec -it %s -- %s", meta.Namespace, meta.Name, pcmd.ShellType)

	if IsDebug {
		PrintInfo("👉 exec command for pod: \n  " + fullCommand)
	}

	command := exec.Command("bash", "-c", fullCommand)
	err := command.Run()
	if err != nil {
		PrintError("exec cmd failed: " + fullCommand)
	}
}

func (pcmd *AmbPodExec) ExecCommand() {
	pcmd.Init()
	meta := pcmd.Meta
	fullCommand := ""
	if pcmd.Meta.Container == "" {
		fullCommand = fmt.Sprintf("kubectl -n %s exec -it %s -- %s", meta.Namespace, meta.Name, pcmd.ShellType)
	} else {
		fullCommand = fmt.Sprintf("kubectl -n %s exec -it %s -c %s -- %s", meta.Namespace, meta.Name, meta.Container, pcmd.ShellType)
	}
	if pcmd.Cmd != "" {
		fullCommand = fullCommand + " -c \"" + pcmd.Cmd + "\""
	}

	if IsDebug {
		PrintInfo("👉 exec command for pod: \n  " + fullCommand)
	}

	cmd := exec.Command("bash", "-c", fullCommand)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	err := cmd.Run()
	if err != nil {
		PrintError("exec cmd failed: " + fullCommand)
	}
}

// ExecCommandInPod 进入Pod交互模式
func (pcmd *AmbPodExec) ExecCommandInPod() (string, error) {
	pcmd.Init()
	meta := pcmd.Meta
	fullCommand := ""
	if pcmd.Meta.Container == "" {
		fullCommand = fmt.Sprintf("kubectl -n %s exec -it %s -- %s", meta.Namespace, meta.Name, pcmd.ShellType)
	} else {
		fullCommand = fmt.Sprintf("kubectl -n %s exec -it %s -c %s -- %s", meta.Namespace, meta.Name, meta.Container, pcmd.ShellType)
	}

	// 带有指定命令
	if pcmd.Cmd != "" {
		fullCommand = fmt.Sprintf("%s -c %s", fullCommand, "\""+pcmd.Cmd+"\"")
	}

	cmd := exec.Command("bash", "-c", fullCommand)

	if IsDebug {
		PrintInfo("👉 exec command in pod: \n  " + fullCommand)
	}

	out, err := cmd.CombinedOutput()
	output := string(out)
	if err != nil {
		PrintInfo("exec command: " + fullCommand)
		PrintError("exec command failed: " + err.Error())
	}
	output = strings.Replace(output, "Unable to use a TTY - input is not a terminal or the right kind of file", "", -1)
	output = RemoveEmptyLines(output)
	output = RemoveEnter(output)
	if IsDebug || pcmd.PrintResult {
		PrintInfo("command result: \n" + output)
	}
	return output, err
}

func (pcmd *AmbPodExec) GrepStdoutLog(keyWord string) {

}
