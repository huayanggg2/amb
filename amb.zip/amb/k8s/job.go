package k8s

import (
	. "acos-magic-box/common"
	"fmt"
	"github.com/spf13/cobra"
	"os"
	"runtime"
	"strings"
	"text/template"
	"time"
)

var req = RedoJobRequest{}

func init() {
	redoJobCmd.PersistentFlags().StringVar(&req.JobName, "from", "", "原Job名称")
	redoJobCmd.PersistentFlags().StringVar(&req.Image, "image", "", "新镜像地址")
	redoJobCmd.PersistentFlags().StringVar(&req.Namespace, "ns", DefaultNamespace, "K8s Namespace")

	redoJobCmd.MarkPersistentFlagRequired("from")
	redoJobCmd.MarkPersistentFlagRequired("ns")
	k8sCmd.AddCommand(redoJobCmd)
}

type RedoJobRequest struct {
	JobName      string
	Image        string
	Namespace    string
	NewJobName   string
	YamlFileName string
}

var redoJobScript = `#!/bin/bash
JOB_FILE="{{ .YamlFileName }}"
/root/yq -i eval 'del(.spec.selector)' ${JOB_FILE}
/root/yq -i eval 'del(.spec.template.metadata)' ${JOB_FILE}
/root/yq -i eval 'del(.status)' ${JOB_FILE}
/root/yq e -i '.metadata.name = "{{ .NewJobName }}"' ${JOB_FILE}
{{ if .Image }}
/root/yq e -i '.spec.template.spec.containers[0].image = "{{ .Image }}"' ${JOB_FILE}
{{ end }}
`

var redoJobCmd = &cobra.Command{
	Use:   "redo-job",
	Short: "重新执行job，适合手动补偿一些初始化任务",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Example: "amb k8s redo-job --from <原job名称> --n <Namespace> [--image 新的镜像地址]",
	Run: func(cmd *cobra.Command, args []string) {
		t1 := time.Now()
		t2 := t1.Format("150405")
		newJobName := req.JobName + "-" + t2
		req.NewJobName = newJobName
		req.YamlFileName = "/tmp/" + newJobName + ".yaml"

		// show all jobs
		ExecCommand(fmt.Sprintf("kubectl -n %s get job", req.Namespace))

		// 检查原始job是否存在
		queryJobOutput, err2 := ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s get job %s", req.Namespace, req.JobName))
		if err2 != nil {
			if strings.Contains(queryJobOutput, "not found") {
				PrintError(fmt.Sprintf("Job [%s] 不存在！", req.JobName))
				return
			} else {
				panic(err2)
			}
		}

		// 读取job yaml
		ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s get job %s -o yaml > %s",
			req.Namespace, req.JobName, req.YamlFileName))
		PrintSuccess("导出原job yaml file: " + req.YamlFileName)

		yqPath := "/root/yq"
		if !DoesFileExist(yqPath) {
			arch := runtime.GOARCH
			ExecCommandAndOutput("wget -O /root/yq https://cnstack-service.oss-cn-hangzhou.aliyuncs.com/amb/libs/yq_linux_" + arch + " && chmod a+x /root/yq")
			PrintSuccess("yq工具下载成功.")
		}

		t, err := template.New("todos").Parse(redoJobScript)
		if err != nil {
			panic(err)
		}
		shellScriptFileName := "/tmp/redo-job.sh"
		shellScriptFile, err := os.Create(shellScriptFileName)
		err = t.Execute(shellScriptFile, req)
		if err != nil {
			panic(err)
		}
		PrintSuccess("shell file: " + shellScriptFileName)

		// 执行shell替换文件
		ExecCommand(fmt.Sprintf("sh %s", shellScriptFileName))
		PrintSuccess("新Job yaml文件生成成功:" + req.YamlFileName)

		ok := YesNoPrompt(fmt.Sprintf("是否立即创建新Job？"), true)
		if ok {
			ExecCommand(fmt.Sprintf("kubectl -n %s apply -f %s", req.Namespace, req.YamlFileName))
		}
	},
}
