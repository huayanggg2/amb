package k8s

import (
	. "acos-magic-box/common"
	"fmt"
	"github.com/manifoldco/promptui"
	"github.com/spf13/cobra"
	"os"
	"strings"
)

var podName string
var shellType string
var execCmd string

func init() {
	entryPodCmd.PersistentFlags().StringVar(&k8sNamespace, "ns", DefaultNamespace, "namespace")
	entryPodCmd.PersistentFlags().StringVar(&shellType, "shell", "", "/bin/bash|/bin/sh")
	entryPodCmd.PersistentFlags().StringVar(&execCmd, "cmd", "", "")

	k8sCmd.AddCommand(entryPodCmd)
	k8sCmd.AddCommand(listPodsCmd)
}

var entryPodCmd = &cobra.Command{
	Use:     "exec",
	Short:   "快速进入Pod",
	Long:    "快速进入Pod，多个pod时可以交互选择",
	Example: "amb k8s exec --ns acos <pod name key>",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if k8sNamespace == "" {
			k8sNamespace = DefaultNamespace
		}
		if len(args) >= 1 {
			podName = args[0]
		} else {
			err := cmd.Help()
			if err != nil {
				return
			}
			os.Exit(0)
		}
		k8sCmd := fmt.Sprintf("kubectl -n %s get pods -o jsonpath='{range .items[*]}{.metadata.name}{\"@\"}{range .spec.containers[*]}{\"/\"}{.name}{end}{\"\\n\"}{end}' | grep %s", k8sNamespace, podName)
		output, err := ExecCommandAndOutput(k8sCmd)
		if err != nil {
			panic(err)
		}
		podNames := SplitLines(output)

		var podWithContainers []string
		for _, pn := range podNames {
			split := strings.Split(pn, "@")
			podName := split[0]
			container := strings.Split(split[1], "/")
			for _, c := range container {
				if c != "" {
					podWithContainers = append(podWithContainers, podName+"/"+c)
				}
			}
		}

		prompt := promptui.Select{
			Label: "请选择一个Pod/Container:",
			Items: podWithContainers,
		}

		_, selectedItem, err := prompt.Run()

		if err != nil {
			fmt.Printf("Prompt failed %v\n", err)
			return
		}

		selectItems := strings.Split(selectedItem, "/")
		selectPod := selectItems[0]
		selectContainer := selectItems[1]
		var podCmd = &AmbPodExec{
			Meta: &AmbPod{
				Namespace: k8sNamespace,
				Name:      selectPod,
				Container: selectContainer,
			},
			Cmd:       execCmd,
			ShellType: shellType,
		}
		podCmd.ExecCommand()
	},
}

var listPodsCmd = &cobra.Command{
	Use:   "list",
	Short: "查询Pod列表",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		var workloadNames []string
		deploys := GetWorkloads("deploy", k8sNamespace)
		for _, d := range deploys {
			workloadNames = append(workloadNames, "Deployment:"+d)
		}
		stsList := GetWorkloads("sts", k8sNamespace)
		for _, d := range stsList {
			workloadNames = append(workloadNames, "StatefulSet:"+d)
		}
		prompt := promptui.Select{
			Label: "请选择Workload",
			Size:  20,
			Items: workloadNames,
		}
		_, selectedWorkload, err := prompt.Run()

		if err != nil {
			fmt.Printf("Prompt failed %v\n", err)
			return
		}

		GetPods(strings.Split(selectedWorkload, ":")[1], k8sNamespace)
		//tools.PrintSuccess(fmt.Sprintf("%v", pods))
	},
}
