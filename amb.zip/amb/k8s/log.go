package k8s

import (
	. "acos-magic-box/common"
	"fmt"
	"github.com/spf13/cobra"
)

var grepLog = &GrepPodStdoutLog{}
var podMeta = &AmbPod{}

// >>>>>>>>>>>>>>> start cmd
func init() {
	logGrepCmd.PersistentFlags().StringVar(&podMeta.Namespace, "ns", DefaultNamespace, "namespace")
	logGrepCmd.PersistentFlags().StringVar(&podMeta.Name, "pod", "", "pod name")
	logGrepCmd.PersistentFlags().IntVar(&grepLog.TailSize, "tail", 500, "tail行数")
	_ = logGrepCmd.MarkPersistentFlagRequired("pod")
	k8sCmd.AddCommand(logGrepCmd)
}

var logGrepCmd = &cobra.Command{
	Use:   "log",
	Short: "查询Pod的标准输出（stdout）日志",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Example: "log --ns acos --pod xxx 'key words'",
	Run: func(cmd *cobra.Command, args []string) {
		grepLog.Meta = podMeta
		if len(args) > 0 {
			grepLog.KeyWord = args[0]
		}

		grepLog.Execute()
	},
}

// <<<<<<<<<<<<<<< end cmd

type GrepPodStdoutLog struct {
	Meta       *AmbPod
	KeyWord    string
	GroupCount bool
	TailSize   int
}

func (gpl *GrepPodStdoutLog) InitDefaults() {
	if gpl.TailSize == 0 {
		gpl.TailSize = 500
	}
}

func (gpl *GrepPodStdoutLog) Execute() string {
	gpl.InitDefaults()
	cmd := fmt.Sprintf("kubectl -n %s logs --tail=%v %s", gpl.Meta.Namespace, gpl.TailSize, gpl.Meta.Name)
	if gpl.KeyWord != "" {
		cmd = fmt.Sprintf("%s | grep '%s'", cmd, gpl.KeyWord)
	}
	if gpl.GroupCount {
		cmd = fmt.Sprintf("%s | sort | uniq -c", cmd)
	}
	output, _ := ExecCommandAndOutput(cmd)
	return output
}
