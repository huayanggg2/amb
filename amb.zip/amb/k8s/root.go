package k8s

import (
	"acos-magic-box/cmd"
	. "acos-magic-box/common"
	"fmt"
	"github.com/spf13/cobra"
)

var k8sNamespace string

var k8sCmd = &cobra.Command{
	Use:     "k8s",
	Aliases: []string{"k"},
	Short:   "K8s tools.",
	Example: `进入容器，可以根据pod名称模糊匹配：amb k8s exec [--ns <namespace>] <pod name>`,
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

func init() {
	k8sCmd.PersistentFlags().StringVar(&k8sNamespace, "ns", "default", "k8s namespace")
	cmd.RootCmd.AddCommand(k8sCmd)

	listAllRes.PersistentFlags().StringVar(&k8sNamespace, "ns", DefaultNamespace, "k8s namespace")
	_ = listAllRes.MarkPersistentFlagRequired("ns")

	deletePvcCmd.PersistentFlags().StringVar(&k8sNamespace, "ns", DefaultNamespace, "k8s namespace")
	_ = deletePvcCmd.MarkPersistentFlagRequired("ns")
	k8sCmd.AddCommand(deletePvcCmd)
}

var deletePvcCmd = &cobra.Command{
	Use:   "delete-pvc",
	Short: SPrintWarn("高危操作！！！删除PVC，一般用于研发环境重新安装组件前彻底清理pvc时使用"),
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		// 1. 列出来涉及到的所有pvc
		PrintWarn("以下为 " + k8sNamespace + " 命名空间中的PVC列表：")
		ExecCommand(fmt.Sprintf("kubectl -n %s get pvc", k8sNamespace))
		toContinue := YesNoPrompt("该操作会彻底删除PVC，确认吗？", true)
		if !toContinue {
			return
		}
		CopyScriptToTemp("delete-workloads.sh")
		output, err := ExecCommandAndOutput(fmt.Sprintf("sh /tmp/delete-workloads.sh %s pvc", k8sNamespace))
		if err != nil {
			PrintError("删除pvc失败！")
			return
		} else {
			PrintInfo(output)
		}
	},
}
