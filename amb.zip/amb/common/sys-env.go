package common

var IsDebug bool
