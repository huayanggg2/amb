#!/bin/bash
ns=$1
wt=$2
if [[ -z "$ns" ]]; then
        echo "Usage: ./delete-workloads.sh <namespace> <type>"
				kubectl get ns | awk 'NR>1' | awk '{print $1}'
        exit 1
fi

kubectl -n $ns get ${wt} | awk 'NR>1' | awk '{print $1}' > ${wt}.list

for name in `cat ${wt}.list`
do
        kubectl -n $ns delete ${wt} $name
done
