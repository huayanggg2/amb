alias k="kubectl"
alias ka="kubectl -n acos"

alias h="helm"
alias ha="helm -n acos"

alias ks="kubectl -n kube-system"
alias kcs="kubectl -n acs-system"
alias kce="kubectl -n cnedas"
alias ke="kubectl -n edas"
alias kp="kubectl -n prometheus"

alias kap="kubectl -n acos get po"
alias kwap="watch kubectl -n acos get po"
alias kacm="kubectl -n acos get cm"
alias kcspo="kubectl -n acs-system get po"
alias kcscm="kubectl -n acs-system get cm"
alias kpd="kubectl -n default-tenant-prj-default"

alias amb="/root/bin/amb"
alias ak="amb k8s"
alias ake="amb k8s exec"