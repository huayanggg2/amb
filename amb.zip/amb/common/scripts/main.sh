#!/bin/bash

zkServer=zk-client-clickhouse:2181/kafka
brokerIdList=$1
if [ -z "$zkServer" ]
then
  echo "zkServer can not be empty"
  exit 1
else
  echo "zkServer:"$zkServer
fi
if [ -z "$brokerIdList" ]
then
  echo "brokerIdList can not be empty"
  exit 2
else
  echo "brokerIdList:" $brokerIdList
fi

echo "###########################start generate##############################"
bash  /opt/bitnami/kafka/autoAssign.sh $zkServer
echo "###########################start execute##############################"
bash  /opt/bitnami/kafka/autoRebalance.sh $zkServer $brokerIdList
echo "###########################end execute##############################"