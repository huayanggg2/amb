#!/bin/bash
BASEDIR=$(dirname "$0")
source $BASEDIR/tools.sh
source $BASEDIR/export-db-envs.sh

tenant_id=''
app_id=''
app_name=''
column_mode=0
debug=0

# >>>>>>>>>> start get opts
usage() {
  text_warn "Usage: mysql-show-front-apps.sh [--column-mode] [--tenant-id 2] [--pid xxxx-yyyy-zzz] [--app-name name-like]"
  exit 0
}

while test $# -gt 0; do
  case "$1" in
      --tenant-id|--tid)
          shift
          if test $# -gt 0; then
            tenant_id=$1
          else
            text_error "no tenant id, --tenant_id xxx"
            exit 1
          fi
          shift
          ;;
      --pid|--app-id)
          shift
          if test $# -gt 0; then
            app_id=$1
          else
            text_error "no app id, --pid xxx"
            exit 1
          fi
          shift
          ;;
      --app-name)
          shift
          if test $# -gt 0; then
            app_name=$1
          else
            text_error "no app name, --app-name xxx"
            exit 1
          fi
          shift
          ;;
      --column-mode)
          shift
          column_mode=1
          shift
          ;;
      --debug)
          shift
          debug=1
          shift
          ;;
      *)
          usage
          return 1;
          ;;
  esac
done
# end get opts <<<<<<<<<<<<<

sql='select id,pid,app_name,status,is_deleted,tenant_id,creator,gmt_create,gmt_modified,tag_set from dtsmart.dt_arms_web_app where 1=1'

# 根据应用Id查询
if [ -n "$app_id" ];then
  sql="$sql and pid='$app_id'"
fi

# 根据租户ID查询
if [ -n "$tenant_id" ];then
  if [ $"$tenant_id" != "ALL" ];then
    sql="$sql and tenant_id='$tenant_id'"
  fi
fi

# 根据应用名称模糊查询
if [ -n "$app_name" ];then
  sql="$sql and app_name like '%${app_name}%'"
fi

# order by
sql="$sql order by id"
if [ "$column_mode" == "1" ]; then
  sql="${sql} \G"
fi

if [ "$debug" == "1" ]; then
  echo "$sql"
fi

mysql --host "$mysql_host" --port "${mysql_port}" -u"${mysql_username}" -p"${mysql_password}" -e "use dtsmart;$sql"