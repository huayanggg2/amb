#!/bin/bash
BASEDIR=$(dirname "$0")

source $BASEDIR/tools.sh
source $BASEDIR/export-db-envs.sh

tenant_id=''
tenant_name=''
column_mode=0
debug=0

# >>>>>>>>>> start get opts
usage() {
  text_warn "Usage: mysql-show-acos-tenant.sh [--column-mode] [--id 2] [--name name-like] [--debug]"
  exit 0
}

while test $# -gt 0; do
  case "$1" in
      --id)
          shift
          if test $# -gt 0; then
            tenant_id=$1
          else
            text_error "no tenant id, --tenant_id xxx"
            exit 1
          fi
          shift
          ;;
      --name)
          shift
          if test $# -gt 0; then
            tenant_name=$1
          else
            text_error "no tenant name to like query, --name xxx"
            exit 1
          fi
          shift
          ;;
      --column-mode)
          shift
          column_mode=1
          shift
          ;;
      --debug)
          shift
          debug=1
          shift
          ;;
      *)
          usage
          return 1;
          ;;
  esac
done
# end get opts <<<<<<<<<<<<<

sql="select id,tenant_name,external_id from dtuic.uic_tenant where 1=1"

# 根据租户Id查询
if [ -n "$tenant_id" ];then
  sql="$sql and id=$tenant_id"
fi

# 根据应用名称模糊查询
if [ -n "$tenant_name" ];then
  sql="$sql and tenant_name like '%${tenant_name}%'"
fi

if [ "$column_mode" == "1" ]; then
  sql="${sql} \G"
fi

if [ "$debug" == "1" ]; then
  echo $sql
fi

mysql --host $mysql_host --port ${mysql_port} -u${mysql_username} -p${mysql_password} -e "use dtuic;${sql}"