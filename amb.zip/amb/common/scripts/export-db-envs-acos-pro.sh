#!/bin/bash
export mysql_host="mysql"
export mysql_port="3306"
export mysql_username="root"
export mysql_password="ACos!@#2022DT"
export dbname="dtsmart"
# echo "$host:$port@$dbname"