#!/bin/bash
data_id=$1
group=$2
tenant=$3
sql="select * from his_config_info where data_id='$data_id' and group_id='$group'"
if [ -n "$tenant" ];then
    sql="$sql and tenant_id='$tenant'"
fi
sql="$sql order by id desc;"
mysql --host $diamond_mysql_host -u$diamond_mysql_user_name -p$diamond_mysql_password --port $diamond_mysql_port -e "use $diamond_mysql_db_name;$sql"