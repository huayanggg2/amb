#!/bin/bash
BASEDIR=$(dirname "$0")
source $BASEDIR/export-db-envs.sh
mysql -hmysql-sharedb.cnedas -uroot -pAliyun@cnstack_nv52r!
show databases;
