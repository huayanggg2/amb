package common

import (
	"regexp"
	"strings"
)

var re = regexp.MustCompile(`(?m)^\s*$[\r\n]*|[\r\n]+\s+\z`)

func RemoveEmptyLines(str string) string {
	return re.ReplaceAllString(str, "")
}

func SplitLines(str string) []string {
	str = RemoveEmptyLines(str)
	return strings.Split(strings.TrimSuffix(str, "\n"), "\n")
}

func RemoveEnter(str string) string {
	return strings.TrimSuffix(str, "\n")
}
