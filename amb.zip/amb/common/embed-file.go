package common

import (
	"embed"
	"fmt"
	"io/ioutil"
)

//go:embed scripts/*.sh
var local embed.FS

func ReadShellScriptContent(fileName string) []byte {
	d, err := local.ReadFile("scripts/" + fileName)
	if err != nil {
		PrintError(err.Error())
		return nil
	}
	return d
}

func ReadShellScriptContentAsString(fileName string) string {
	return string(ReadShellScriptContent(fileName))
}

// CopyScriptToTemp 复制bin中的文件到系统目录
func CopyScriptToTemp(fileName string) {
	content := ReadShellScriptContent(fileName)
	err := ioutil.WriteFile("/tmp/"+fileName, content, 0666)
	if err != nil {
		fmt.Printf("copy file failed :\n%s\n", fileName)
	} else {
		if IsDebug {
			PrintSuccess(fmt.Sprintf("copy file %s", fileName))
		}
	}
}
