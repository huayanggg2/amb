package common

import (
	"strings"
	"testing"
)

func TestReadFile(t *testing.T) {
	content := ReadShellScriptContent("entry-mysql.sh")
	if len(content) <= 0 {
		t.Fail()
	}
	if !strings.Contains(string(content), "mysql") {
		t.Fail()
	}
}
