package common

import (
	"fmt"
	"log"
	"os"
)

func WriteToFile(content string, file string) {
	f, err := os.Create(file)
	if err != nil {
		log.Fatal(err)
	}

	n, err := f.WriteString(content + "\n")
	if err != nil {
		log.Fatal(err)
	}
	if IsDebug {
		fmt.Printf("Write file %s with %d bytes\n", file, n)
	}
	f.Sync()
}

func DoesFileExist(fileName string) bool {
	_, error := os.Stat(fileName)
	// check if error is "file not exists"
	if os.IsNotExist(error) {
		return false
	} else {
		return true
	}
	return false
}
