package common

var DefaultNamespace = "acos"
