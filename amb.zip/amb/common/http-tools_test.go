package common

import (
	"fmt"
	"testing"
)

func TestWanIp(t *testing.T) {
	ip := GetWanIP()
	fmt.Println(ip)
}
