package common

type BaseDbQuery struct {
	ColumnMode bool
}
