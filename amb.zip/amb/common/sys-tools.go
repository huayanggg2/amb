package common

import (
	"fmt"
	"github.com/spf13/cobra"
	"os"
	"os/exec"
	"strings"
)

type CmdCallback interface {
	OnSuccess(output string)
	OnError(output string, err error)
}

type CmdRequest struct {
	Cmd      string
	Callback CmdCallback
}

func (req CmdRequest) ExecCommand() {
	ExecCommandV2(req.Cmd, req.Callback)
}

func ExecCommand(cmdStr string) {
	ExecCommandV2(cmdStr, nil)
}

// ExecCommandV2 完全模拟shell标准操作
func ExecCommandV2(cmdStr string, callback CmdCallback) {
	if IsDebug {
		PrintInfo("👉 exec command for common: \n  " + cmdStr)
	}
	cmd := exec.Command("bash", "-c", cmdStr)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	err := cmd.Run()
	if err != nil {
		if callback != nil {
			callback.OnError("", err)
		} else {
			PrintError(err.Error())
		}
	}
}

func removeUselessInfo(output string) string {
	output = strings.ReplaceAll(output, "Defaulting container name to mysql.", "")
	output = strings.Replace(output, "Unable to use a TTY - input is not a terminal or the right kind of file", "", -1)
	return output
}

func (req CmdRequest) ExecCommandAndOutput() (string, error) {
	return ExecCommandAndOutputV2(req.Cmd, req.Callback)
}

func ExecCommandAndOutput(cmd string) (string, error) {
	return ExecCommandAndOutputV2(cmd, nil)
}

func ExecCommandAndOutputV2(cmd string, callback CmdCallback) (string, error) {
	command := exec.Command("bash", "-c", cmd)
	fullCommand := cmd
	if IsDebug {
		PrintInfo("👉 exec command for common: \n  " + fullCommand)
	}

	out, err := command.CombinedOutput()
	output := string(out)
	output = removeUselessInfo(output)
	output = RemoveEmptyLines(output)
	if err != nil {
		if callback != nil {
			callback.OnError(output, err)
		} else {
			fmt.Printf("combined out:\n%s\n", output)
			PrintError(fmt.Sprintf("cmd.Run() failed with %s", err))
		}
		return output, err
	}

	if IsDebug {
		PrintInfo(fmt.Sprintf("get exec output:⬇\n[%v]", output))
	}

	output = removeUselessInfo(output)
	if output != "" {
		if IsDebug {
			PrintSuccessWithoutIcon("Exec and Output: \n" + output)
		}
	}
	output = RemoveEnter(output)

	// callback
	if callback != nil {
		callback.OnSuccess(output)
	}

	return output, err
}

func SetCommonFlags(cmd *cobra.Command) {
	debugFlag := cmd.Flag("debug")
	if debugFlag != nil && debugFlag.Value.String() == "true" {
		IsDebug = true
		PrintWarn(">>> 已启用Debug模式 <<<")
	} else {
		IsDebug = false
		//tools.PrintWarn(">>> 已禁用Debug模式 <<<")
	}
}

// 默认需要复制的脚本列表
var defaultShellScripts = []string{"tools.sh"}

// CopyFilesToPod 复制脚本文件到pod内
func CopyFilesToPod(namespace string, podName string, container string, toDir string, files []string) {
	files = append(files, defaultShellScripts...)
	for _, file := range files {
		fileInfo := strings.Split(file, ":")

		fromFile := fileInfo[0]
		toFile := fileInfo[0]
		if len(fileInfo) == 2 {
			toFile = fileInfo[1]
		}

		from := "/tmp/" + fromFile
		var to = toDir + "/" + toFile
		CopyScriptToTemp(fromFile)

		CopyFileToPod(namespace, podName, container, from, to)
	}
}

func CopyFilesToPodV1(namespace string, workloadType string, workloadName string, container string, toDir string, files []string) {
	files = append(files, defaultShellScripts...)
	for _, file := range files {
		fileInfo := strings.Split(file, ":")

		fromFile := fileInfo[0]
		toFile := fileInfo[0]
		if len(fileInfo) == 2 {
			toFile = fileInfo[1]
		}

		from := "/tmp/" + fromFile
		var to = toDir + "/" + toFile
		CopyScriptToTemp(fromFile)

		CopyFileToPodV1(namespace, workloadType, workloadName, container, from, to)
	}
}

func CopyFileToPod(namespace string, podName string, container string, from string, to string) {
	cmd := fmt.Sprintf("kubectl -n %s cp %s -c %s %s:%s", namespace, from, container, podName, to)
	ExecCommandAndOutput(cmd)
}

func CopyFileToPodV1(namespace string, workloadType string, workloadName string, container string, from string, to string) {
	cmd := fmt.Sprintf("cat %s | kubectl -n %s exec -i %s/%s -c %s -- tee %s > /dev/null", from, namespace, workloadType, workloadName, container, to)
	ExecCommandAndOutput(cmd)
}
