package common

import (
	"bytes"
	"io"
)

type CapturingPassThroughWriter struct {
	buf    bytes.Buffer
	w      io.Writer
	output string
}

// NewCapturingPassThroughWriter creates new CapturingPassThroughWriter
func NewCapturingPassThroughWriter(w io.Writer) *CapturingPassThroughWriter {
	return &CapturingPassThroughWriter{
		w: w,
	}
}

func (w *CapturingPassThroughWriter) Write(d []byte) (int, error) {
	w.buf.Write(d)
	w.output = string(d)
	return w.w.Write(d)
}

// Bytes returns bytes written to the writer
func (w *CapturingPassThroughWriter) Bytes() []byte {
	return w.buf.Bytes()
}

func (w *CapturingPassThroughWriter) GetOutput() string {
	return w.output
}
