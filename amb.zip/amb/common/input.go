package common

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func GetInput(message string, required bool) string {
	var buffer [512]byte
	fmt.Print(message, ":")
	_, err := os.Stdin.Read(buffer[:])
	if err != nil {
		fmt.Println("read error:", err)
		return ""
	}
	str := string(buffer[:])

	if str == "" && required {
		GetInput(message, true)
	}

	return str
}

func YesNoPrompt(label string, def bool) bool {
	choices := "Y/n"
	if !def {
		choices = "y/N"
	}

	r := bufio.NewReader(os.Stdin)
	var s string

	for {
		fmt.Fprintf(os.Stderr, "%s (%s) ", ColorYellow+label+ColorReset, choices)
		s, _ = r.ReadString('\n')
		s = strings.TrimSpace(s)
		if s == "" {
			return def
		}
		s = strings.ToLower(s)
		if s == "y" || s == "yes" {
			return true
		}
		if s == "n" || s == "no" {
			return false
		}
	}
}
