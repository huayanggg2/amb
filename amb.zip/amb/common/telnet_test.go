package common

import (
	"github.com/reiver/go-telnet"
	"testing"
)

func TestTelnet(t *testing.T) {
	var caller telnet.Caller = telnet.StandardCaller

	//@TOOD: replace "example.net:23" with address you want to connect to.
	err := telnet.DialToAndCall("120.79.200.161:30383", caller)
	if err != nil {
		t.Fail()
	}
}
