package common

import "strings"

func ContainsArrayItem(strItems []string, subStr string, likeMatch bool) bool {
	for _, item := range strItems {
		if likeMatch {
			if strings.Contains(item, subStr) || strings.Contains(subStr, item) {
				return true
			}
		} else {
			if item == subStr {
				return true
			}
		}
	}
	return false
}
