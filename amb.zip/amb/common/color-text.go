package common

import (
	"fmt"
)

const (
	ColorReset  = "\033[0m"
	ColorRed    = "\033[31m"
	ColorGreen  = "\033[32m"
	ColorYellow = "\033[33m"
	ColorBlue   = "\033[34m"
	ColorPurple = "\033[35m"
	ColorCyan   = "\033[36m"
	ColorWhite  = "\033[37m"
)

// PrintColorText 输出彩色文字
func PrintColorText(text string, color string) {
	fmt.Println(color + text + ColorReset)
}

// PrintColorText 输出彩色文字
func SPrintColorText(text string, color string) string {
	return color + text + ColorReset
}

func SPrintWarn(text string) string {
	return SPrintColorText(text, ColorYellow)
}

func PrintError(text string) {
	PrintColorText("❌  "+text, ColorRed)
}

func PrintWarn(text string) {
	PrintColorText("⚠️  "+text, ColorYellow)
}

func PrintSuccess(text string) {
	PrintColorText("✅  "+text, ColorGreen)
}
func PrintSuccessWithoutIcon(text string) {
	PrintColorText(text, ColorGreen)
}

func PrintInfo(text string) {
	PrintColorText("📝  "+text, ColorCyan)
}

func PrintStep(text string) {
	PrintColorText(text, ColorBlue)
}

func PrintWhite(text string) {
	PrintColorText(text, ColorWhite)
}
