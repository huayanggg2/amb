package common

import (
	"io"
	"log"
	"net/http"
)

func GetWanIP() string {
	var client http.Client
	resp, err := client.Get("http://ifconfig.me")
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusOK {
		bodyBytes, err := io.ReadAll(resp.Body)
		if err != nil {
			log.Fatal(err)
		}
		bodyString := string(bodyBytes)
		if IsDebug {
			PrintSuccess("Get Wan IP: " + bodyString)
		}
		return bodyString
	}
	return ""
}
