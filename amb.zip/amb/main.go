package main

// 要引入子模块的菜单需要用隐藏import方式导入
// _ "acos-magic-box/clickhouse"
import (
	_ "acos-magic-box/acos"
	_ "acos-magic-box/arms"
	_ "acos-magic-box/clickhouse"
	"acos-magic-box/cmd"
	_ "acos-magic-box/cnstack"
	_ "acos-magic-box/debug"
	_ "acos-magic-box/jlogclickhouse"
	_ "acos-magic-box/k8s"
	_ "acos-magic-box/kafka"
	_ "acos-magic-box/zookeeper"
	"os"
)

var version string

func main() {
	if version == "" {
		version = "dev"
	}
	err := os.Setenv("VERSION", version)
	if err != nil {
		panic(err)
	}
	_ = cmd.Execute()
}
