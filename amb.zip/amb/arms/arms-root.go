package clickhouse

import (
	"acos-magic-box/cmd"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var armsRootCmd = &cobra.Command{
	Use:   "arms",
	Short: "arms工具",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

func init() {
	cmd.RootCmd.AddCommand(armsRootCmd)
}
