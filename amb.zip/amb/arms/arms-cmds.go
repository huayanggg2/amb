package clickhouse

import (
	. "acos-magic-box/common"
	"acos-magic-box/replicate"
	"github.com/spf13/cobra"
	"os"
)

var rcNum int

func init() {
	cltReplicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	cltReplicaCmd.MarkPersistentFlagRequired("rcNum")

	armsRootCmd.AddCommand(cltReplicaCmd)

	rcdReplicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	rcdReplicaCmd.MarkPersistentFlagRequired("rcNum")

	armsRootCmd.AddCommand(rcdReplicaCmd)
}

var rcdReplicaCmd = &cobra.Command{
	Use:   "rcdrc",
	Short: "修改arms-retcode副本数!",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum < 1 {
			PrintError("副本数不能为偶数，且不小于1")
			os.Exit(0)
		}
		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/arms-retcode-nginx/values.yaml")
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		replicate.WriteYaml(ap+"/charts/arms-retcode-nginx/values.yaml", m)
		output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
	},
}

var cltReplicaCmd = &cobra.Command{
	Use:   "cltrc",
	Short: "修改arms-collector副本数",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum < 1 {
			PrintError("副本数不能为偶数，且不小于1")
			os.Exit(0)
		}
		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/arms-collector/values.yaml")
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		replicate.WriteYaml(ap+"/charts/arms-collector/values.yaml", m)
		output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
	},
}
