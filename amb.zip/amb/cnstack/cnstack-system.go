package cnstack

import (
	. "acos-magic-box/common"
	"fmt"
	"github.com/spf13/cobra"
	"strings"
)

func init() {
	RootCmd.AddCommand(entryPodCmd)
}

type SysComponent struct {
	Name      string
	Namespace string
}

func NewInstance(name string, ns string) SysComponent {
	return SysComponent{
		Namespace: ns,
		Name:      name,
	}
}

var components = []SysComponent{
	NewInstance("dncs", "cnedas"),
	NewInstance("mysql-sharedb", "cnedas"),
	NewInstance("vcns-oss", "vcns-oss"),
	NewInstance("redis-shareredis", "cnedas"),
}

var entryPodCmd = &cobra.Command{
	Use:     "comp-status",
	Aliases: []string{"cs"},
	Short:   "CNStack Component状态",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		CheckComponents()
	},
}

// CheckComponents 检查和acos相关的组件状态
func CheckComponents() bool {
	var flag = true
	for _, component := range components {
		cn := component.Name
		ns := component.Namespace
		cmdStr := fmt.Sprintf("kubectl -n %s get component -l adp.aliyuncs.com/component-name=%s | grep -v Completed", ns, cn)
		output, _ := ExecCommandAndOutput(cmdStr)
		if strings.Contains(output, "Exception") {
			flag = false
			PrintError(fmt.Sprintf("%s@%s Exception", cn, ns))
		}
		if strings.Contains(output, "Pending") {
			flag = false
			PrintError(fmt.Sprintf("%s@%s Pending", cn, ns))
		}
		if strings.Contains(output, "Running") {
			PrintSuccess(fmt.Sprintf("%s@%s OK", cn, ns))
		}
	}
	return flag
}
