package cnstack

import (
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var (
	RootCmd = &cobra.Command{
		Use:     "cnstack",
		Aliases: []string{"cs"},
		Short:   "cnstack tools",
		PreRun: func(cmd *cobra.Command, args []string) {
			SetCommonFlags(cmd)
		},
	}
)

func init() {
	RootCmd.AddCommand(reDoAcosMinioJob)
	//cmd.RootCmd.AddCommand(RootCmd)
}

var reDoAcosMinioJob = &cobra.Command{
	Use:   "redo-acos-job",
	Short: "重新执行acos minio job初始化文件包",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		ExecCommandAndOutput("kubectl -n acos get job | grep minio-vcns-init | awk 'NR==1{print $1}' | xargs kubectl -n acos get job -o yaml > acos-minio-job.yaml")
	},
}
