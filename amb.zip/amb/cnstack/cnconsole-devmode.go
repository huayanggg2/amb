package cnstack

import (
	. "acos-magic-box/common"
	"fmt"
	"github.com/spf13/cobra"
)

func init() {
	RootCmd.AddCommand(cnConsoleDevMode)
}

var cnConsoleDevMode = &cobra.Command{
	Use:   "cnconsole-dev-mode",
	Short: "开启cnconsole同步最新前端资源",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		PrintInfo("1. Patching AK/SK...")
		c := `kubectl -n acs-system patch secret/cn-console-secret --type merge -p '{"data": {"console-ak": "TFRBSTV0NjFlN1RKWEt4ZFZYSGNLTDZN", "console-sk": "N1VBVTN1c0tvMWtMWGtsc1FYOEh1czZ0WXdrWkVX"}}'`
		ExecCommandAndOutput(c)

		PrintInfo("2. Deleting cn console pods...")
		ExecCommandAndOutput("kubectl -n acs-system get po | grep cn-console | grep -v Complete | awk '{print \"kubectl -n acs-system delete po \"$1 \" &\"}' | sh")

		wanIp := GetWanIP()
		PrintSuccess(fmt.Sprintf("3. 请到 https://cn-console.alibaba-inc.com/#/envBind?envId=&productId=14&productVersionId=58 绑定环境，选择IP：%s:30383", wanIp))
	},
}
