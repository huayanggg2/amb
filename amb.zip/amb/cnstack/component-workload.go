package cnstack

import (
	. "acos-magic-box/common"
	"fmt"
	"strings"
)

type ComponentWorkloadMeta struct {
	Namespace         string
	MainContainer     string
	AppLabelKey       string
	AppLabelValue     string
	PodNameStartWith  string
	BreakWhenNotReady bool
}

var (
	AppAcosCollector = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "arms-collector",
		AppLabelKey:   "app.kubernetes.io/name",
	}
	AppRetCode = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "arms-retcode-nginx",
		MainContainer: "arms-retcode-nginx",
		AppLabelKey:   "app.kubernetes.io/name",
	}
	AppAcosConsole = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "yc-console",
		AppLabelKey:   "app.kubernetes.io/name",
	}
	AppClickhouse = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "clickhouse",
		AppLabelKey:   "app.kubernetes.io/name",
	}
	AppAcosJlogserver = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "jlogserver",
		AppLabelKey:   "app.kubernetes.io/name",
	}
	AppAcosJlogclickhouse = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "jlogclickhouse",
		MainContainer: "jlogclickhouse",
		AppLabelKey:   "app.kubernetes.io/name",
	}
	AppKafkaBroker = &ComponentWorkloadMeta{
		Namespace:         "acos",
		AppLabelValue:     "alibaba-kafka-broker",
		AppLabelKey:       "adp.aliyuncs.com/component-name",
		PodNameStartWith:  "alibaba-kafka-cluster-uncommercial",
		BreakWhenNotReady: true,
	}
	AppAcosMinio = &ComponentWorkloadMeta{
		Namespace:         "vcns-oss",
		AppLabelKey:       "adp.aliyuncs.com/component-name",
		AppLabelValue:     "vcns-oss",
		PodNameStartWith:  "",
		BreakWhenNotReady: true,
	}
	AppAlertManagerInitAiopsSmartAlert = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "alertmanager-init-aiops-smartalert",
	}
	AppAlertManagerProcessAiopsSmartAlert = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "alertmanager-process-aiops-smartalert",
	}
	AppCloudOpsProcessAiopsSmartAlert = &ComponentWorkloadMeta{
		Namespace:     "acos",
		AppLabelValue: "cloudops-process-aiops-smartalert",
	}

	AppCnedasMysql = &ComponentWorkloadMeta{
		Namespace:     "cnedas",
		MainContainer: "mysql",
		AppLabelKey:   "adp.aliyuncs.com/component-name",
		AppLabelValue: "mysql-sharedb",
	}

	AppAcosProMysql = &ComponentWorkloadMeta{
		Namespace:     "acos",
		MainContainer: "mysql",
		AppLabelKey:   "app",
		AppLabelValue: "mysql",
	}

	AppAmbTool = &ComponentWorkloadMeta{
		Namespace:        "acos",
		MainContainer:    "amb",
		PodNameStartWith: "amb-tools",
	}
)

// FindPodNames 查询匹配的pod名称
func (meta *ComponentWorkloadMeta) FindPodNames() []string {
	if meta.AppLabelKey != "" && meta.AppLabelValue != "" {
		labelFilter := "-l " + meta.AppLabelKey + "=" + meta.AppLabelValue
		cmd := "kubectl -n " + meta.Namespace + " get po " + labelFilter + " | awk 'NR>1{print $1}'"
		out, _ := ExecCommandAndOutput(cmd)
		return strings.Split(strings.TrimSuffix(out, "\n"), "\n")
	} else if meta.PodNameStartWith != "" {
		cmd := "kubectl -n " + meta.Namespace + " get po | grep " + meta.PodNameStartWith + " | awk '{print $1}'"
		out, _ := ExecCommandAndOutput(cmd)
		return strings.Split(strings.TrimSuffix(out, "\n"), "\n")
	} else {
		panic("需要提供PodNameStartWith或者【AppLabelKey/AppLabelValue】")
	}
}

// GrepStdoutLog 从标准输出中过滤关键字
func (meta *ComponentWorkloadMeta) GrepStdoutLog(keywords []string) []string {
	var matchLogs []string

	var grepExpress = ""
	for _, k := range keywords {
		if grepExpress != "" {
			grepExpress = grepExpress + "|"
		}
		grepExpress = grepExpress + "grep -i '" + k + "' -A 3 -B 3"
	}

	names := meta.FindPodNames()
	for _, podName := range names {
		output, err := ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s logs %s -c %s | %s | tail -n 10",
			meta.Namespace, podName, meta.MainContainer, grepExpress))
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
		lines := SplitLines(output)
		for _, line := range lines {
			matchLogs = append(matchLogs, line)
		}
	}

	return matchLogs
}
