package cnstack

import (
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"fmt"
	"github.com/spf13/cobra"
	"golang.org/x/exp/slices"
	"strconv"
	"strings"
	"time"
)

var namespace string
var component string

func init() {
	reinstallComponent.PersistentFlags().StringVar(&namespace, "ns", DefaultNamespace, "命名空间")
	reinstallComponent.PersistentFlags().StringVar(&component, "component", "acos", "组件名称")
	err := reinstallComponent.MarkPersistentFlagRequired("ns")
	if err != nil {
		panic(err)
	}
	err = reinstallComponent.MarkPersistentFlagRequired("component")
	if err != nil {
		panic(err)
	}
	RootCmd.AddCommand(reinstallComponent)
}

var reinstallComponent = &cobra.Command{
	Use:     "reinstall",
	Short:   "重新安装组件，客户环境不要操作！！！",
	Example: "amb cs reinstall --ns acos --component acos",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		reinstallCmd()
	},
}

func reinstallCmd() {
	PrintInfo("1. 缩容所有关联了pvc的workload")
	PrintInfo("2. 删除PVC")
	PrintInfo(fmt.Sprintf("3. helm uninstall -n %s %s", namespace, component))
	ok := YesNoPrompt(fmt.Sprintf("高危操作：是否要重新安装%s，该操作会删除ClickHouse的监控数据？", component), true)
	if ok {
		ok2 := YesNoPrompt(fmt.Sprintf("高危操作：请再次确认是否要重新安装%s？", component), true)
		if ok2 {
			doReinstall()
		} else {
			fmt.Println("Exit.")
		}
	} else {
		fmt.Println("Exit.")
	}
}

// 统计处于销毁状态的Pod数量
func countTerminatingPod(namespace string) int {
	output, err := ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s get pod | grep Terminating | wc -l", namespace))
	if err != nil {
		panic(err)
	}
	count, err := strconv.Atoi(output)
	if err != nil {
		panic(err)
	}
	return count
}

// 本次操作哪些需要被缩容
var crdWorkloads []k8s.CrdWorkload

// 支持的crd类型
var crdKinds = []string{"RedisCluster", "MysqlCluster", "ZookeeperCluster"}

func getReplicas(namespace string, kind string, name string) (int, error) {
	output, err := ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s get %s %s -o=jsonpath='{.spec.replicas}'", namespace, kind, name))
	if output != "" {
		return strconv.Atoi(output)
	}
	return 0, err
}

func initCrdList() {
	for _, crdKind := range crdKinds {
		output, err := ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s get %s | awk 'NR>1{print $1}'", namespace, crdKind))
		if err != nil {
			panic(err)
		}
		crdNames := SplitLines(output)
		for _, crdName := range crdNames {
			if strings.Contains(crdName, "No resources found") || strings.Contains(crdName, "error") {
				continue
			}
			PrintInfo("Found crd: " + crdName)
			crdWorkloads = append(crdWorkloads, k8s.CrdWorkload{Kind: crdKind, Name: crdName})
		}
	}
}

func doReinstall() {
	initCrdList()                    // 初始化crd列表
	var ourCrdList []k8s.CrdWorkload // 当前namespace中存在的crd
	stsOutput, _ := ExecCommandAndOutput(fmt.Sprintf("kubectl -n %s get sts | awk 'NR>1{print $1}'", namespace))
	instList := SplitLines(stsOutput)
	PrintWarn("1. 开始缩容依赖PVC的Workloads")

	var whileListName []string
	for _, wl := range crdWorkloads {
		whileListName = append(whileListName, wl.Name)
	}

	for _, inst := range instList {
		if ContainsArrayItem(whileListName, inst, true) {
			if IsDebug {
				PrintInfo("handle crd: " + inst)
			}
			idx := slices.IndexFunc(crdWorkloads, func(c k8s.CrdWorkload) bool { return c.Name == inst })
			workload := crdWorkloads[idx]

			replicas, err := getReplicas(namespace, workload.Kind, workload.Name)
			if err != nil {
				panic(err)
			}

			ourCrdList = append(ourCrdList, k8s.CrdWorkload{
				Kind:     workload.Kind,
				Name:     inst,
				Replicas: replicas,
			})

			k8s.PatchReplicasToZero(namespace, workload.Kind, inst)
		} else {
			k8s.PatchReplicasToZero(namespace, "sts", inst)
		}
	}

	// 等待缩容的Pod都销毁
	for {
		terminatingCount := countTerminatingPod(namespace)
		if terminatingCount > 0 {
			PrintWarn(fmt.Sprintf("剩余 %v Pod待销毁。。。", terminatingCount))
			time.Sleep(2 * time.Second)
		} else {
			PrintSuccess("缩容Pod已完全销毁。")
			break
		}
	}

	ExecCommand(fmt.Sprintf("kubectl -n %s get pvc", namespace))
	if YesNoPrompt(fmt.Sprintf("高危操作：是否删除%s的PVC存储？", component), false) {
		PrintWarn("2. 正在删除pvcs...")
		CopyScriptToTemp("delete-workloads.sh")
		output, err := ExecCommandAndOutput(fmt.Sprintf("sh /tmp/delete-workloads.sh %s pvc", namespace))
		if err != nil {
			PrintError("删除pvc失败！")
			return
		} else {
			PrintInfo(output)
		}
	}

	ExecCommand(fmt.Sprintf("kubectl -n %s get job", namespace))
	if YesNoPrompt(fmt.Sprintf("是否清理 %s 的Job？", component), true) {
		PrintWarn("3. 正在删除jobs...")
		CopyScriptToTemp("delete-workloads.sh")
		output, err := ExecCommandAndOutput(fmt.Sprintf("sh /tmp/delete-workloads.sh %s job", namespace))
		if err != nil {
			PrintError("删除job失败！")
			return
		} else {
			PrintInfo(output)
		}
	}

	PrintWarn("4. 正在重新安装...")

	// 恢复缩零的crd
	for _, crd := range ourCrdList {
		PrintInfo(fmt.Sprintf("恢复crd: %s/%s, replicas: %v", crd.Kind, crd.Name, crd.Replicas))
		k8s.PatchReplicas(namespace, crd.Kind, crd.Name, crd.Replicas)
	}

	output, err := ExecCommandAndOutput(fmt.Sprintf("helm uninstall -n %s %s", namespace, component))
	if err != nil {
		PrintError("helm uninstall失败")
		return
	} else {
		PrintInfo(output)
	}
	PrintSuccess(fmt.Sprintf("命令执行完毕，请查看pod最新状态: watch kubectl -n %s get po", namespace))
}
