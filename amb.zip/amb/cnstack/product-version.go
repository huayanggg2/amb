package cnstack

import (
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

func init() {
	RootCmd.AddCommand(productVersionCmd)
}

var productVersionCmd = &cobra.Command{
	Use:     "product-version",
	Aliases: []string{"cs"},
	Short:   "CNStack Component状态",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		// 打印cnstack底座版本
		ExecCommand("kubectl -n acs-system get app")
		ExecCommand("kubectl -n acs-system get component")

		// 打印五合一版本
		ExecCommand("kubectl -n cnedas get app")
		ExecCommand("kubectl -n cnedas get component")
	},
}
