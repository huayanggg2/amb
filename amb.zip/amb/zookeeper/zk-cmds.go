package clickhouse

import (
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"acos-magic-box/replicate"
	"github.com/spf13/cobra"
	"os"
)

var rcNum int

func init() {
	replicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	replicaCmd.MarkPersistentFlagRequired("rcNum")

	zkRootCmd.AddCommand(entryPodCmd)
	zkRootCmd.AddCommand(entryPodCmdV1)
	zkRootCmd.AddCommand(replicaCmd)
}

var entryPodCmdV1 = &cobra.Command{
	Use:   "podv1",
	Short: "进入Zookeeper的Pod交互模式, cnstack 2.0版本",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		var ckPodCmd = &k8s.AmbPodExec{
			Meta: &k8s.AmbPod{
				Namespace: "acos",
				Container: "zookeeper",
				Name:      "zk-clickhouse-0",
			},
		}
		ckPodCmd.Init().ExecCommand()
	},
}

var entryPodCmd = &cobra.Command{
	Use:   "pod",
	Short: "进入Zookeeper的Pod交互模式 - cnstack 2.1版本",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		var ckPodCmd = &k8s.AmbPodExec{
			Meta: &k8s.AmbPod{
				Namespace: "acos",
				Container: "zookeeper",
				Name:      "zk-clickhouse-0",
			},
		}
		ckPodCmd.Init().ExecCommand()
	},
}

var replicaCmd = &cobra.Command{
	Use:   "rc",
	Short: "修改zookeeper副本数,不能为偶数",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum%2 == 0 || rcNum < 1 {
			PrintError("副本数不能为偶数，且不小于1")
			os.Exit(0)
		}
		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/clickhouse-cluster/values.yaml")
		m["zookeeper"].(map[interface{}]interface{})["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		replicate.WriteYaml(ap+"/charts/clickhouse-cluster/values.yaml", m)
		output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
		PrintInfo(output)
		if err != nil {
			panic(err)
		}
	},
}
