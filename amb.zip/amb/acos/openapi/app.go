package openapi

import (
	"acos-magic-box/acos/app"
	"os"
	"text/template"
	"time"
)

var headerTemplate = `
--header "cnstack-uname: {{ .App.UserName }}" \
--header "cnstack-tenant-id: {{ .App.TenantId }}" \
{{- if .App.ProjectId }} 
--header "cnstack-project-id: {{ .App.ProjectId }}" \
{{- end }}
--header "accesskeyId: {{ .Ak }}" \
--header "accessKeySecret: {{ .Sk }}"
`

var createAppUrlTemplate = `
curl -k --location "http://{{ .Address }}/acos/api/v1/arms/app" \
--data-urlencode "pid={{ .App.AppId }}" \
--data-urlencode "appName={{ .App.AppName }}" \
--data-urlencode "source={{ .App.Source }}" \
--data-urlencode "appType={{ .App.AppType }}" \
--data-urlencode "siteType={{ .App.SiteType }}"
--header "Content-Type: application/x-www-form-urlencoded" \
` + headerTemplate

var appListTemplate = `curl -k --location "http://{{ .Address }}/acos/api/v1/arms/app/query-apps" \` + headerTemplate

var delAppTemplate = `curl -k -X DELETE --location "http://{{ .Address }}/acos/api/v1/arms/app/{{.App.AppId}}" \` + headerTemplate

var metricsTemplate = `curl -k --location "http://{{ .Address }}/acos/api/v1/arms/app/query-metrics?dimensions=rootIp&end={{ .CustomVars.end }}&interval=300&measures=rt&measures=count&metric=appstat.incall&start={{ .CustomVars.start }}" \` + headerTemplate

type AppRequest struct {
	Address    string
	Https      bool
	IgnoreSsl  bool
	App        *app.AcosApp
	Ak         string
	Sk         string
	CustomVars map[string]interface{}
}

func (request *AppRequest) Init() {
	if request.Address == "" {
		request.Address = defaultServer
	}
}

var defaultServer = "hub-iam-gateway.kube-public.svc"

func (request *AppRequest) Create() {
	request.Init()
	t, err := template.New("todos").Parse(createAppUrlTemplate)
	if err != nil {
		panic(err)
	}
	err = t.Execute(os.Stdout, request)
	if err != nil {
		panic(err)
	}
}

func (request *AppRequest) List() {
	request.Init()
	t, err := template.New("todos").Parse(appListTemplate)
	if err != nil {
		panic(err)
	}
	err = t.Execute(os.Stdout, request)
	if err != nil {
		panic(err)
	}
}

func (request *AppRequest) Delete() {
	request.Init()
	t, err := template.New("todos").Parse(delAppTemplate)
	if err != nil {
		panic(err)
	}
	err = t.Execute(os.Stdout, request)
	if err != nil {
		panic(err)
	}
}

func (request *AppRequest) QueryMetrics() {
	request.Init()
	m := make(map[string]interface{})
	m["start"] = time.Now().Unix() - (10 * 60)
	m["end"] = time.Now().Unix()
	request.CustomVars = m
	t, err := template.New("todos").Parse(metricsTemplate)
	if err != nil {
		panic(err)
	}
	err = t.Execute(os.Stdout, request)
	if err != nil {
		panic(err)
	}
}
