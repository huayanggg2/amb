package app

import (
	. "acos-magic-box/acos/utils"
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"fmt"
	"strings"
)

// Query 应用查询对象
type Query struct {
	App          *AcosApp
	ReturnOutput bool
	ColumnMode   bool
}

func (q *Query) QueryFromDb() string {
	mysqlInfo := GetMysqlInfo(DefaultNamespace)
	var files = []string{"mysql-show-acos-apps.sh"}

	CopyFilesToPod(mysqlInfo.Namespace, mysqlInfo.PodName, mysqlInfo.MainContainer, "/root", files)

	cmd := "sh /root/mysql-show-acos-apps.sh"
	if q.App.TenantId != "" {
		cmd = fmt.Sprintf("%s --tenant-id %v", cmd, q.App.TenantId)
	}
	if q.App.AppId != "" {
		cmd = fmt.Sprintf("%s --app-id %v", cmd, q.App.AppId)
	}
	if q.App.AppName != "" {
		cmd = fmt.Sprintf("%s --app-name %v", cmd, q.App.AppName)
	}
	if q.ColumnMode {
		cmd = fmt.Sprintf("%s --column-mode", cmd)
	}
	if IsDebug {
		cmd = fmt.Sprintf("%s --debug", cmd)
	}

	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: mysqlInfo.Namespace,
			Container: mysqlInfo.MainContainer,
			Name:      mysqlInfo.PodName,
		},
		Cmd: cmd,
	}
	if q.ReturnOutput {
		output, _ := ckPodCmd.Init().ExecCommandInPod()
		return output
	}
	ckPodCmd.Init().ExecCommand()
	return ""
}

// ShowAcosApps 查询应用列表
func (q *Query) ShowAcosApps() []*AcosApp {
	q.ReturnOutput = true
	appsOutput := q.QueryFromDb()
	var appList []*AcosApp
	apps := strings.Split(strings.TrimSuffix(appsOutput, "\n"), "\n")
	var isData = false
	for _, appObj := range apps {
		if isData {
			appInfo := strings.Split(appObj, "\t")
			tenantIdStr := appInfo[5]
			creatorIdStr := appInfo[6]

			var appObj = &AcosApp{
				AppId:     appInfo[1],
				AppName:   appInfo[2],
				TenantId:  tenantIdStr,
				CreatorId: creatorIdStr,
				TagSet:    appInfo[9],
			}
			appObj.SetMetadata()
			appList = append(appList, appObj)
		}
		if strings.Contains(appObj, "tenant_id") && !strings.Contains(appObj, "select") {
			isData = true
		}
	}

	return appList
}
