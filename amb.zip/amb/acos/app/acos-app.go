package app

import "strings"

type AcosApp struct {
	AppId     string
	AppName   string
	UserName  string
	TenantId  string
	CreatorId string
	ProjectId string
	Source    string
	AppType   string
	SiteType  string
	TagSet    string
}

func (app *AcosApp) SetMetadata() {
	if app.TagSet == "" {
		return
	}
	tagList := strings.Split(app.TagSet, ",")
	for _, tag := range tagList {
		if strings.Contains(tag, "project_id") {
			projectId := strings.Split(tag, ":")[1]
			app.ProjectId = projectId
		}
	}
}
