package tenant

import (
	. "acos-magic-box/acos/utils"
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"fmt"
)

// Query 应用查询对象
type Query struct {
	Id   string
	Name string

	// 列查询模式
	ColumnMode   bool
	ReturnOutput bool
}

func (q *Query) QueryFromDb() string {
	mysqlInfo := GetMysqlInfo(DefaultNamespace)

	// 复制一些脚本到mysql容器
	var files = []string{"mysql-show-acos-tenants.sh"}
	CopyFilesToPod(mysqlInfo.Namespace, mysqlInfo.PodName, mysqlInfo.Workload.MainContainer, "/root", files)

	cmd := "sh /root/mysql-show-acos-tenants.sh"

	if q.ColumnMode {
		cmd = fmt.Sprintf("%s --column-mode", cmd)
	}
	if IsDebug {
		cmd = fmt.Sprintf("%s --debug", cmd)
	}

	if q.Id != "" {
		cmd = fmt.Sprintf("%s --id %v", cmd, q.Id)
	}
	if q.Name != "" {
		cmd = fmt.Sprintf("%s --name %v", cmd, q.Name)
	}

	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: mysqlInfo.Namespace,
			Container: mysqlInfo.MainContainer,
			Name:      mysqlInfo.PodName,
		},
		Cmd: cmd,
	}
	if q.ReturnOutput {
		output, _ := ckPodCmd.Init().ExecCommandInPod()
		return output
	}
	ckPodCmd.Init().ExecCommand()
	return ""
}
