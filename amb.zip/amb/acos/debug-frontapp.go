package acos

import (
	app3 "acos-magic-box/acos/frontapp"
	"acos-magic-box/clickhouse"
	"acos-magic-box/cnstack"
	. "acos-magic-box/common"
	"acos-magic-box/debug"
	"acos-magic-box/k8s"
	"fmt"
	"github.com/spf13/cobra"
	"net/url"
	"strings"
)

var frontApp = app3.FrontApp{}

func init() {
	debugFrontAppCmd.PersistentFlags().StringVar(&frontApp.AppId, "pid", "", "应用ID")
	debugFrontAppCmd.PersistentFlags().StringVar(&frontApp.TenantId, "tenant-id", "", "租户ID")
	debugFrontAppCmd.PersistentFlags().StringVar(&frontApp.AppName, "app-name", "", "应用名称，模糊查询")
	debugFrontAppCmd.MarkPersistentFlagRequired("pid")
	debug.DebugCmd.AddCommand(debugFrontAppCmd)
}

var debugFrontAppCmd = &cobra.Command{
	Use:     "front",
	Aliases: []string{"metrics"},
	Short:   "排查前端无监控数据问题",
	Example: "",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		debugFrontApp()
	},
}

func printFrontHelp() {
	PrintInfo("###### 监控数据链路")
	PrintInfo("\t#1 bl.js > retcode-nginx")
	PrintInfo("\t#2 retcode-nginx > /home/admin/logs/<租户ID_用户IDxxx.log>")
	PrintInfo("\t#3 logkit pro < retcode-nginx")
	PrintInfo("\t#4 logkit pro > jlogserver")
	PrintInfo("\t#5 jlogserver ----push----> kafka")
	PrintInfo("\t#6 kafka ----pull< jlogclickhouse")
	PrintInfo("###### End")
}

func debugFrontApp() {
	printFrontHelp()
	if frontApp.AppId == "" {
		appId := GetInput("应用ID", true)
		fmt.Print(appId)
	}

	var app *app3.FrontApp
	var appQuery = &app3.FrontQuery{
		App: &frontApp,
	}
	apps := appQuery.ShowApps()
	if len(apps) == 1 {
		app = apps[0]
		PrintSuccess(fmt.Sprintf("根据应用ID %s 查询到应用名称 %s", frontApp.AppId, app.AppName))
	} else {
		PrintError(fmt.Sprintf("应用 %s 不存在，请检查参数！", frontApp.AppId))
		return
	}

	// 查询到匹配应用打印相关信息方便后续排查
	if app.AppId != "" {
		PrintSuccess(fmt.Sprintf("查询到匹配的应用，ID: %s， 租户: %v， 用户: %v",
			app.AppId, app.TenantId, app.CreatorId))
	}

	podNames := cnstack.AppRetCode.FindPodNames()
	for _, podName := range podNames {
		showFrontUserMetricLogs(podName, app.CreatorId)
		checkFrontLatestMetricsLog(podName)
	}

	toContinue := YesNoPrompt("请确认上报到RetCode nginx的最新时间是否准确？", true)
	if !toContinue {
		PrintWarn("请继续手动排查。。。")
		// TODO 检查retcode服务是否正常，尤其是r.png是否可以访问
		return
	}

	// 继续查询clickhouse
	ckDbName := fmt.Sprintf("distributed_%v", app.TenantId)
	ckTableName := "arms_frontend_log"
	exist := clickhouse.CheckTableExist(ckDbName, ckTableName)
	if !exist {
		PrintError(fmt.Sprintf("ClickHouse表 [%s/%s] 不存在！", ckDbName, ckTableName))
		if errorInJlogClickhouseLogs() {
			return
		}
	}
	latestTimeInCk := clickhouse.QueryFrontAppLatestTime(app.AppId, app.TenantId)
	ok := YesNoPrompt("请确认最新数据时间："+latestTimeInCk, true)
	if ok {
		PrintSuccess("恭喜你，一切安好。")
	} else {
		PrintWarn("暂无答案!")
		PrintInfo("如果是研发环境可以尝试重新安装acos，执行命令： amb cs reinstall --namespace acos --component acos")
	}
}

// 检查看jlogclickouse是否有异常日志
// true：结果排查
// false：没问题，继续排查
func errorInJlogClickhouseLogs() bool {
	logs := cnstack.AppAcosJlogclickhouse.GrepStdoutLog([]string{"error", "arms_frontend_log"})
	for _, logLine := range logs {
		if strings.Contains(logLine, "create table failed") {
			PrintWarn("创建表失败，可能是因为ClickHouse服务不稳定，请自行检查！")
			return true
		}
	}
	return false
}

func checkFrontLatestMetricsLog(podName string) {
	logFile := fmt.Sprintf("/home/admin/logs/%s.log", url.QueryEscape(frontApp.AppId))
	var podCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: cnstack.AppRetCode.Namespace,
			Container: cnstack.AppRetCode.MainContainer,
			Name:      podName,
		},
		Cmd: fmt.Sprintf("tail -n 1 %s", logFile),
	}
	output, err := podCmd.Init().ExecCommandInPod()
	if err != nil {
		panic(err)
	}
	latestTime := strings.Split(output, "||")[3]
	PrintWarn(fmt.Sprintf("最近上报时间 %v", latestTime))
}

func showFrontUserMetricLogs(podName string, tenantId string) {
	traceLogDir := fmt.Sprintf("/home/admin/logs/%s*.log", tenantId)
	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: cnstack.AppRetCode.Namespace,
			Container: cnstack.AppRetCode.MainContainer,
			Name:      podName,
		},
		Cmd: "ls -lh " + traceLogDir,
	}
	PrintInfo(fmt.Sprintf("从Retcode [ %s ]查询到租户[ %s ]的监控数据日志[ %s ]文件如下：", podName, tenantId, traceLogDir))
	output, _ := ckPodCmd.Init().ExecCommandInPod()
	fmt.Println(output)
}
