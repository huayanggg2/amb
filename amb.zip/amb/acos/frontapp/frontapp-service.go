package app

import (
	. "acos-magic-box/acos/utils"
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"fmt"
	"net/url"
	"strings"
)

// FrontQuery Query 应用查询对象
type FrontQuery struct {
	App        *FrontApp
	ColumnMode bool
}

type FrontApp struct {
	AppId     string
	AppName   string
	TenantId  string
	CreatorId string
	TagSet    string
}

func (q *FrontQuery) QueryFromDb() string {
	mysqlInfo := GetMysqlInfo(DefaultNamespace)

	// 复制一些脚本到mysql容器
	var files = []string{"mysql-show-front-apps.sh"}
	CopyFilesToPod(mysqlInfo.Namespace, mysqlInfo.PodName, mysqlInfo.Workload.MainContainer, "/root", files)

	cmd := "sh /root/mysql-show-front-apps.sh"
	if q.App.TenantId != "" {
		cmd = fmt.Sprintf("%s --tenant-id %v", cmd, q.App.TenantId)
	}
	if q.App.AppId != "" {
		decodeAppId, _ := url.QueryUnescape(q.App.AppId)
		if IsDebug {
			PrintInfo("Decode appid: " + q.App.AppId + " to " + decodeAppId)
		}
		cmd = fmt.Sprintf("%s --app-id %v", cmd, decodeAppId)
	}
	if q.App.AppName != "" {
		cmd = fmt.Sprintf("%s --app-name %v", cmd, q.App.AppName)
	}
	if q.ColumnMode {
		cmd = fmt.Sprintf("%s --column-mode", cmd)
	}
	if IsDebug {
		cmd = fmt.Sprintf("%s --debug", cmd)
	}

	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: mysqlInfo.Namespace,
			Container: mysqlInfo.MainContainer,
			Name:      mysqlInfo.PodName,
		},
		Cmd: cmd,
	}
	output, _ := ckPodCmd.Init().ExecCommandInPod()
	return output
}

// ShowApps 查询应用列表
func (q *FrontQuery) ShowApps() []*FrontApp {
	appsOutput := q.QueryFromDb()
	var appList []*FrontApp
	apps := strings.Split(strings.TrimSuffix(appsOutput, "\n"), "\n")
	var isData = false
	for _, appObj := range apps {
		if isData {
			appInfo := strings.Split(appObj, "\t")
			tenantIdStr := appInfo[5]
			creatorIdStr := appInfo[6]

			var appObj = &FrontApp{
				AppId:     appInfo[1],
				AppName:   appInfo[2],
				TenantId:  tenantIdStr,
				CreatorId: creatorIdStr,
				TagSet:    appInfo[9],
			}
			appList = append(appList, appObj)
		}
		if strings.Contains(appObj, "tenant_id") && !strings.Contains(appObj, "select") {
			isData = true
		}
	}

	return appList
}
