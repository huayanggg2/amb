package utils

import (
	"acos-magic-box/cnstack"
	"acos-magic-box/common"
	"acos-magic-box/k8s"
	"fmt"
	"strings"
)

type MysqlInfo struct {
	Workload      *cnstack.ComponentWorkloadMeta
	PodName       string
	Namespace     string
	MainContainer string
}

type MysqlCmdCallback struct {
}

func (mc *MysqlCmdCallback) OnSuccess(output string) {

}
func (mc *MysqlCmdCallback) OnError(output string, err error) {
	if !strings.Contains(output, "No such file or directory") {
		panic(err)
	}
}

func GetMysqlInfo(ns string) MysqlInfo {
	// 1. get app in current namespace
	//cnstackApps := k8s.GetWorkloads("sts", ns)
	//hasAcosPro := common.ContainsArrayItem(cnstackApps, "mysql-sharedb", false)
	var mysqlWordLoad *cnstack.ComponentWorkloadMeta
	//if hasAcosPro {
	//	mysqlWordLoad = cnstack.AppAmbTool
	//} else {
	//	mysqlWordLoad = cnstack.AppAmbTool
	//}
	mysqlWordLoad = cnstack.AppAcosProMysql
	mysqlPodNames := mysqlWordLoad.FindPodNames()

	if len(mysqlPodNames) == 0 {
		common.PrintError("no mysql pod")
	}
	mysqlPodName := mysqlPodNames[0]

	mysqlShellFile := "export-db-envs-acos-pro.sh"
	//if hasAcosPro {
	//	mysqlShellFile = "export-db-envs-acos-pro.sh"
	//}

	// 获取数据库service
	// helm -n acos get values acos -o yaml √
	// kubectl -n acos get cm yc-console -o yaml | grep -E "dtsmart.mysql.host" | grep -v spring | sed 's/ //g' | awk -F"=" '{print $2}'

	// 复制一些脚本到mysql容器
	var files = []string{"set-bash.sh", mysqlShellFile + ":export-db-envs.sh"}
	common.CopyFilesToPod(mysqlWordLoad.Namespace, mysqlPodName, mysqlWordLoad.MainContainer, "/root", files)

	// 复制的文件可能分布在不同pod里，需要判断后才能确认使用哪个pod
	for _, mpn := range mysqlPodNames {
		pcmd := fmt.Sprintf("kubectl -n %s exec -it %s -c %s -- /bin/bash -c \"%s\"",
			mysqlWordLoad.Namespace, mpn, mysqlWordLoad.MainContainer, "ls /root/"+mysqlShellFile)
		output, _ := common.CmdRequest{
			Cmd:      pcmd,
			Callback: &MysqlCmdCallback{},
		}.ExecCommandAndOutput()
		if strings.Contains(output, mysqlShellFile) {
			if common.IsDebug {
				common.PrintSuccess("Using mysql pod to exec sql: " + mysqlPodName)
			}
			mysqlPodName = mpn
		}
	}

	// set dash > bash
	setBashCmd := k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: mysqlWordLoad.Namespace,
			Container: mysqlWordLoad.MainContainer,
			Name:      mysqlPodName,
		},
		Cmd: "sh /root/set-bash.sh",
	}
	setBashCmd.ExecCommand()

	return MysqlInfo{
		Workload:      mysqlWordLoad,
		PodName:       mysqlPodName,
		Namespace:     mysqlWordLoad.Namespace,
		MainContainer: mysqlWordLoad.MainContainer,
	}
}
