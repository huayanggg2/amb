package acos

import (
	"acos-magic-box/acos/tenant"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

func init() {
	showTenantsCmd.PersistentFlags().StringVar(&TenantId, "id", "", "根据租户ID精确查询")
	showTenantsCmd.PersistentFlags().StringVar(&TenantName, "name", "", "根据租户名称模糊查询")
	showTenantsCmd.PersistentFlags().BoolVar(&ColumnMode, "cm", false, "启用mysql的列视图查看结果")
	showTenantsCmd.PersistentFlags().BoolVar(&ColumnMode, "column-mode", false, "启用mysql的列视图查看结果")
	TenantCmd.AddCommand(showTenantsCmd)
}

var showTenantsCmd = &cobra.Command{
	Use:   "list",
	Short: "查询所有租户",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		query := tenant.Query{
			Id:         TenantId,
			Name:       TenantName,
			ColumnMode: ColumnMode,
		}
		query.QueryFromDb()
	},
}
