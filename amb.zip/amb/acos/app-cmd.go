package acos

import (
	"acos-magic-box/acos/app"
	"acos-magic-box/acos/openapi"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var appRequest = openapi.AppRequest{}
var apmDemo = AppDemo{}

func init() {
	showAppsCmd.PersistentFlags().BoolVar(&ColumnMode, "column-mode", false, "启用mysql的列视图查看结果")
	showAppsCmd.PersistentFlags().BoolVar(&ColumnMode, "cm", false, "启用mysql的列视图查看结果")
	AppCmd.AddCommand(showAppsCmd)

	createAppTemplateCmd.PersistentFlags().StringVar(&appRequest.Ak, "ak", "", "AccessKey ID")
	createAppTemplateCmd.PersistentFlags().StringVar(&appRequest.Sk, "sk", "", "AccessKey Secret")
	createAppTemplateCmd.PersistentFlags().StringVar(&GlobalApp.UserName, "username", "", "所属账号名称")

	createAppTemplateCmd.MarkPersistentFlagRequired("ak")
	createAppTemplateCmd.MarkPersistentFlagRequired("sk")
	createAppTemplateCmd.MarkPersistentFlagRequired("username")
	createAppTemplateCmd.MarkPersistentFlagRequired("app-name")
	createAppTemplateCmd.MarkPersistentFlagRequired("tenant-id")
	createAppTemplateCmd.MarkPersistentFlagRequired("project-id")
	//AppCmd.AddCommand(createAppTemplateCmd)

	getAppsTemplateCmd.PersistentFlags().StringVar(&appRequest.Ak, "ak", "", "AccessKey ID")
	getAppsTemplateCmd.PersistentFlags().StringVar(&appRequest.Sk, "sk", "", "AccessKey Secret")
	getAppsTemplateCmd.PersistentFlags().StringVar(&GlobalApp.TenantId, "tenant-id", "default-tenant", "租户ID")
	getAppsTemplateCmd.PersistentFlags().StringVar(&GlobalApp.UserName, "username", "", "所属账号名称")
	getAppsTemplateCmd.MarkPersistentFlagRequired("ak")
	getAppsTemplateCmd.MarkPersistentFlagRequired("sk")
	getAppsTemplateCmd.MarkPersistentFlagRequired("username")
	getAppsTemplateCmd.MarkPersistentFlagRequired("tenant-id")
	//AppCmd.AddCommand(getAppsTemplateCmd)

	delAppTemplateCmd.PersistentFlags().StringVar(&appRequest.Ak, "ak", "", "AccessKey ID")
	delAppTemplateCmd.PersistentFlags().StringVar(&appRequest.Sk, "sk", "", "AccessKey Secret")
	delAppTemplateCmd.PersistentFlags().StringVar(&GlobalApp.TenantId, "tenant-id", "default-tenant", "租户ID")
	delAppTemplateCmd.PersistentFlags().StringVar(&GlobalApp.AppId, "pid", "", "应用ID")
	delAppTemplateCmd.PersistentFlags().StringVar(&GlobalApp.UserName, "username", "", "所属账号名称")
	delAppTemplateCmd.MarkPersistentFlagRequired("ak")
	delAppTemplateCmd.MarkPersistentFlagRequired("sk")
	delAppTemplateCmd.MarkPersistentFlagRequired("pid")
	delAppTemplateCmd.MarkPersistentFlagRequired("username")
	delAppTemplateCmd.MarkPersistentFlagRequired("tenant-id")
	//AppCmd.AddCommand(delAppTemplateCmd)

	queryMetricsTemplateCmd.PersistentFlags().StringVar(&appRequest.Ak, "ak", "", "AccessKey ID")
	queryMetricsTemplateCmd.PersistentFlags().StringVar(&appRequest.Sk, "sk", "", "AccessKey Secret")
	queryMetricsTemplateCmd.PersistentFlags().StringVar(&GlobalApp.TenantId, "tenant-id", "default-tenant", "租户ID")
	queryMetricsTemplateCmd.PersistentFlags().StringVar(&GlobalApp.UserName, "username", "", "所属账号名称")
	queryMetricsTemplateCmd.MarkPersistentFlagRequired("ak")
	queryMetricsTemplateCmd.MarkPersistentFlagRequired("sk")
	queryMetricsTemplateCmd.MarkPersistentFlagRequired("username")
	queryMetricsTemplateCmd.MarkPersistentFlagRequired("tenant-id")
	//AppCmd.AddCommand(queryMetricsTemplateCmd)

	// 创建apm demo
	deployApmDemo.PersistentFlags().StringVar(&apmDemo.LicenseKey, "licenseKey", "", "licenseKey，可以在acos[接入应用]界面获取")
	deployApmDemo.PersistentFlags().StringVar(&apmDemo.AppName, "appName", "", "应用名称，不设置默认规则为：apm-demo-%Y%m%d-%H%M%S")
	deployApmDemo.PersistentFlags().StringVar(&apmDemo.Namespace, "ns", DefaultNamespace, "K8s Namespace，如果要立即创建demo则需要设置")
	deployApmDemo.PersistentFlags().StringVar(&apmDemo.Image, "image", "", "Demo镜像地址")
	//AppCmd.AddCommand(deployApmDemo)
}

var showAppsCmd = &cobra.Command{
	Use:   "list",
	Short: "查询应用列表",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		query := app.Query{
			App:        &GlobalApp,
			ColumnMode: ColumnMode,
		}
		query.QueryFromDb()
	},
}

var createAppTemplateCmd = &cobra.Command{
	Use:     "template-create",
	Short:   "输出创建应用的url模板",
	Example: "amb app template-create --username admin --ak 45fe2974cd924ca28d69c7e527c58df8 --sk 4ae6333876a147cbaa7a9d26acd64f4a --app-name test-apm --tenant-id default-tenant --project-id default-tenant-prj",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		appRequest.App = &GlobalApp
		appRequest.Create()
	},
}

var getAppsTemplateCmd = &cobra.Command{
	Use:     "template-list",
	Short:   "输出查询应用的url模板",
	Example: "amb app template-list --username admin --ak 45fe2974cd924ca28d69c7e527c58df8 --sk 4ae6333876a147cbaa7a9d26acd64f4a --tenant-id default-tenant",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		appRequest.App = &GlobalApp
		appRequest.List()
	},
}

var delAppTemplateCmd = &cobra.Command{
	Use:     "template-delete",
	Short:   "输出删除应用的url模板",
	Example: "amb app template-delete --username admin --ak 45fe2974cd924ca28d69c7e527c58df8 --sk 4ae6333876a147cbaa7a9d26acd64f4a --tenant-id default-tenant --pid xxxx-yyy",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		appRequest.App = &GlobalApp
		appRequest.Delete()
	},
}

var queryMetricsTemplateCmd = &cobra.Command{
	Use:     "template-metrics",
	Short:   "输出查询metrics的url模板",
	Example: "amb app template-delete --username admin --ak 45fe2974cd924ca28d69c7e527c58df8 --sk 4ae6333876a147cbaa7a9d26acd64f4a --tenant-id default-tenant --pid xxxx-yyy",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		appRequest.App = &GlobalApp
		appRequest.QueryMetrics()
	},
}

var deployApmDemo = &cobra.Command{
	Use:     "create-apm-demo",
	Short:   "快速部署一个Apm Demo",
	Example: "amb app create-apm-demo [--licenseKey <2_2@aa5f461335b820c>] --appName xxx [-ns <yyyy>]",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		apmDemo.Create()
	},
}
