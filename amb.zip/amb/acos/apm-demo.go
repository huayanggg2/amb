package acos

import (
	. "acos-magic-box/common"
	"fmt"
	"os"
	"text/template"
	"time"
)

var apmDemoDeployTemplate = `
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .AppName }}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: apm-demo
  template:
    metadata:
      labels:
        app: apm-demo
    spec:
      containers:
      - name: apm-demo
        image: {{ .Image }} 
        imagePullPolicy: Always
        env:
        - name: foo
          value: bar
        {{- if .LicenseKey }}
        - name: LICENSE_KEY
          value: {{ .LicenseKey }}
        {{- end }}
        {{- if .AppName }}
        - name: APP_NAME
          value: {{ .AppName }}
        {{- end }}
`

type AppDemo struct {
	LicenseKey string
	AppName    string
	Namespace  string
	Image      string
}

func (request *AppDemo) Init() {
	if request.Namespace == "" {
		request.Namespace = "default"
	}
	if request.AppName == "" {
		dateStr := time.Now().Format("20060102-150405")
		request.AppName = "acos-apm-demo-" + dateStr
	}
	if request.Image == "" {
		request.Image = "acos-registry.cn-hangzhou.cr.aliyuncs.com/acos/apm-demo:v2.1"
	}
	if request.LicenseKey == "" {
		request.LicenseKey = "2_2@aa5f461335b820c"
	}
}

func (request *AppDemo) Create() {
	request.Init()

	PrintInfo("AppName: " + request.AppName)
	PrintInfo("LicenseKey: " + request.LicenseKey)
	PrintInfo("Image: " + request.Image)
	ok := YesNoPrompt("请确认关键信息是否正确以便继续？", true)
	if !ok {
		return
	}

	t, err := template.New("todos").Parse(apmDemoDeployTemplate)
	if err != nil {
		panic(err)
	}
	apmDemoDeployTplFileName := "/tmp/acos-apm-demo.yaml"
	apmDemoDeployTplFile, err := os.Create(apmDemoDeployTplFileName)
	err = t.Execute(apmDemoDeployTplFile, request)
	if err != nil {
		panic(err)
	}
	PrintSuccess("应用名称为：" + request.AppName)
	PrintSuccess("Deployment文件已经创建：" + apmDemoDeployTplFileName)
	ok = YesNoPrompt(fmt.Sprintf("是否立即在 %s 命名空间下创建Deployment？", request.Namespace), true)
	cmd := fmt.Sprintf("kubectl -n %s apply -f %s", request.Namespace, apmDemoDeployTplFileName)
	if ok {
		ExecCommand(cmd)
	} else {
		PrintInfo("您也可以手动执行下面命令来创建Apm Demo:")
		PrintSuccess("\t" + cmd)
	}
}
