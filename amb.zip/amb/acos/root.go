package acos

import (
	"acos-magic-box/acos/app"
	"acos-magic-box/cmd"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var UserId string
var UserName string
var TenantId string
var TenantName string
var ColumnMode bool
var DbMode string

var GlobalApp = app.AcosApp{}

var AppCmd = &cobra.Command{
	Use:   "app",
	Short: "应用监控工具：查询应用列表、应用无数据排查",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

var TenantCmd = &cobra.Command{
	Use:     "tenant",
	Aliases: []string{"t"},
	Short:   "租户相关",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

var UserCmd = &cobra.Command{
	Use:     "user",
	Aliases: []string{"u"},
	Short:   "用户相关",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

func init() {
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.AppId, "pid", "", "应用ID")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.UserName, "username", "", "用户名，例如admin")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.AppName, "app-name", "", "应用名称，模糊查询")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.TenantId, "tenant-id", "", "租户ID")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.ProjectId, "project-id", "", "项目ID")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.Source, "source", "TEST", "EDAS|CSB")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.AppType, "appType", "TRACE", "TRACE|XTRACE")
	//AppCmd.PersistentFlags().StringVar(&GlobalApp.SiteType, "siteType", "", "Skywalking|Zipkin|Jaeger|OpenTelemetry")

	cmd.RootCmd.AddCommand(AppCmd)
	cmd.RootCmd.AddCommand(TenantCmd)
	//cmd.RootCmd.AddCommand(UserCmd)
}
