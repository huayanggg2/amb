package acos

import (
	app2 "acos-magic-box/acos/app"
	"acos-magic-box/clickhouse"
	. "acos-magic-box/common"
	"acos-magic-box/debug"
	"fmt"
	"github.com/spf13/cobra"
)

func init() {
	debugAppLogCmd.PersistentFlags().StringVar(&GlobalApp.AppId, "pid", "", "应用ID")
	debugAppLogCmd.MarkPersistentFlagRequired("pid")
	debug.DebugCmd.AddCommand(debugAppLogCmd)
}

var debugAppLogCmd = &cobra.Command{
	Use:     "log",
	Short:   "排查应用日志数据问题",
	Example: "amb debug log --pid xxx-yyy-zzz",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		debugAppLog()
	},
}

func debugAppLog() {
	if GlobalApp.AppId == "" {
		appId := GetInput("应用ID", true)
		fmt.Print(appId)
	}

	var app *app2.AcosApp
	var appQuery = &app2.Query{
		App: &GlobalApp,
	}
	apps := appQuery.ShowAcosApps()
	if len(apps) == 1 {
		app = apps[0]
		PrintSuccess(fmt.Sprintf("根据应用ID %s 查询到应用名称 %s", GlobalApp.AppId, app.AppName))
	} else {
		PrintError(fmt.Sprintf("应用 %s 不存在，请检查参数！", GlobalApp.AppId))
		return
	}

	// 查询到匹配应用打印相关信息方便后续排查
	if app.AppId != "" {
		PrintSuccess(fmt.Sprintf("查询到匹配的应用，ID: %s， 租户: %v， 用户: %v, 项目：%v",
			app.AppId, app.TenantId, app.CreatorId, app.ProjectId))
	}

	appLogLatestTime := clickhouse.QueryAppLogLatestTime(app.AppId, app.ProjectId, app.TenantId)
	PrintWarn("应用日志最新数据时间点：：" + appLogLatestTime)
	ok := YesNoPrompt("请确认ClickHouse中数据时间点："+appLogLatestTime, true)
	if ok {
		PrintSuccess("一切安好")
	} else {
		PrintWarn("无法推断原因，请手动排查！")
		return
	}
}
