package acos

import (
	app2 "acos-magic-box/acos/app"
	"acos-magic-box/clickhouse"
	"acos-magic-box/cnstack"
	. "acos-magic-box/common"
	"acos-magic-box/debug"
	"acos-magic-box/k8s"
	"fmt"
	"github.com/spf13/cobra"
	"strconv"
	"strings"
	"time"
)

func init() {
	debugApmCmd.PersistentFlags().StringVar(&GlobalApp.AppId, "pid", "", "应用ID")
	debugApmCmd.PersistentFlags().StringVar(&GlobalApp.TenantId, "tenant-id", "", "租户ID")
	debugApmCmd.PersistentFlags().StringVar(&GlobalApp.AppName, "app-name", "", "应用名称，模糊查询")
	debugApmCmd.MarkPersistentFlagRequired("pid")
	debug.DebugCmd.AddCommand(debugApmCmd)
}

var debugApmCmd = &cobra.Command{
	Use:     "apm",
	Aliases: []string{"metrics"},
	Short:   "排查应用无监控数据问题",
	Example: "",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		debugApm()
	},
}

func printHelp() {
	PrintInfo("###### 监控数据链路")
	PrintInfo("\t#1 agent > collector")
	PrintInfo("\t#2 jlogserver ---pull---< collector")
	PrintInfo("\t#3 jlogserver ---push---< kafka")
	PrintInfo("\t#4 jlogclickhouse ---pull---< kafka")
	PrintInfo("\t#5 jlogclickhouse ---push---< clickhouse")
	PrintInfo("###### End")
}

func debugApm() {
	printHelp()
	if GlobalApp.AppId == "" {
		appId := GetInput("应用ID", true)
		fmt.Print(appId)
	}

	var userId string
	var app *app2.AcosApp
	var appQuery = &app2.Query{
		App: &GlobalApp,
	}
	apps := appQuery.ShowAcosApps()
	if len(apps) == 1 {
		app = apps[0]
		userId = fmt.Sprintf("%v_%v", app.TenantId, app.CreatorId)
		PrintSuccess(fmt.Sprintf("根据应用ID %s 查询到应用名称 %s", GlobalApp.AppId, app.AppName))
	} else {
		PrintError(fmt.Sprintf("应用 %s 不存在，请检查参数！", GlobalApp.AppId))
		return
	}

	// 查询到匹配应用打印相关信息方便后续排查
	if app.AppId != "" {
		PrintSuccess(fmt.Sprintf("查询到匹配的应用，ID: %s， 租户: %v， 用户: %v, 项目：%v",
			app.AppId, app.TenantId, app.CreatorId, app.ProjectId))
	}

	var metadataLatestItem string
	var spanLatestItem string
	podNames := cnstack.AppAcosCollector.FindPodNames()
	for _, collectorPodName := range podNames {
		showUserMetricLogs(collectorPodName, userId)
		metadataLatestItem = getLatestMetricsLog(collectorPodName, userId, "metadata.log", "3", metadataLatestItem)
		spanLatestItem = getLatestMetricsLog(collectorPodName, userId, "stat-span.log", "1", spanLatestItem)
	}

	// 检查是否有数据上报
	if len(metadataLatestItem) == 0 && len(spanLatestItem) == 0 {
		PrintWarn("1. 没有上报任何数据！！！ 请检查口agent到collector域名是否通畅！")
		PrintWarn("2. 请转到容器内执行 telnet hub-ingress.kube-public.svc 9994 是否通畅？")
		return
	}

	// 检查数据上报的时间
	continueFlow := checkMetricLog(metadataLatestItem, "Metadata-主机监控", "3")
	if !continueFlow {
		return
	}
	checkMetricLog(spanLatestItem, "Span-接口调用", "1")

	var toContinue string
	fmt.Print("请确认上报到Collector的最新时间是否准确？[y or n]")
	_, _ = fmt.Scanf("%s", &toContinue)
	if "Y" != strings.ToUpper(toContinue) {
		PrintWarn("请继续手动排查。。。")
		return
	}

	// 查询clickhouse中的数据最新上报时间
	metricsStatus, err := clickhouse.QueryMetadataLatestTime(app.AppId, app.TenantId)
	if err != nil {
		PrintError("从Clickhouse查询数据失败，原因：\n\t" + err.Error())
		return
	}
	if metricsStatus.MetadataTs == "" && metricsStatus.RpcTs == "" {
		PrintWarn("Metadata和Span均无数据写入到ClickHouse!")
		if clickHouseNoDatabase(app.TenantId) {
			return
		}
		if clickHouseIsReadonly() {
			return
		}
		PrintError("无数据写入到Clickhouse！")
		return
	} else {
		PrintWarn("Metadata最新数据时间点：" + metricsStatus.MetadataTs)
		PrintWarn("接口调用最新数据时间点：" + metricsStatus.RpcTs)
		fmt.Print("请确认ClickHouse中的数据是否正常？[y or n]")
		_, err = fmt.Scanf("%s", &toContinue)
		if err != nil {
			panic(err)
		}
		if "Y" != strings.ToUpper(toContinue) {
			if clickHouseIsReadonly() {
				return
			}
			if clickHouseNoDatabase(app.TenantId) {
				return
			}
		} else {
			PrintSuccess("一切安好")
		}
	}

	PrintInfo("排查结束！")
}

// 检查看clickhouse的表是否处于只读状态
// true：结果排查
// false：没问题，继续排查
func clickHouseIsReadonly() bool {
	logs := cnstack.AppAcosJlogclickhouse.GrepStdoutLog([]string{"Table is in readonly mode"})
	for _, logLine := range logs {
		if strings.Contains(logLine, "TABLE_IS_READ_ONLY") {
			PrintWarn("zookeeper中ClickHouse数据已损坏！")
			return true
		}
	}
	return false
}

// 检查看clickhouse的表是否未创建
// true：结果排查
// false：没问题，继续排查
func clickHouseNoDatabase(tenantId string) bool {
	databaseName := fmt.Sprintf("distributed_%v", tenantId)
	logs := cnstack.AppAcosJlogclickhouse.GrepStdoutLog([]string{databaseName, "UNKNOWN_TABLE"})
	for _, logLine := range logs {
		if strings.Contains(logLine, "TABLE_IS_READ_ONLY") {
			PrintWarn("zookeeper中ClickHouse数据已损坏！")
			return true
		}
	}
	return false
}

func checkMetricLog(latestLog string, metricsTypeName string, metricsTypeCode string) bool {
	var multiLines = SplitLines(latestLog)
	if IsDebug {
		PrintInfo(fmt.Sprintf("get metadata from collector, length: %v\n%v", len(multiLines), multiLines))
	}
	if len(multiLines) == 0 || multiLines[0] == "" {
		return false
	}
	var dateList []string
	for _, log := range multiLines {
		// 检查cpu指标是否有收集到
		if strings.Contains(log, metricsTypeCode+"|") {
			var tmp = strings.Split(log, "|")
			var ts = tmp[1]

			tsInt, err := strconv.ParseInt(ts, 10, 64)
			if err != nil {
				panic(err)
			}
			t := time.Unix(tsInt/1000, 0)
			dateStr := t.Format("2006/01/02 15:04:05")
			dateList = append(dateList, dateStr)
			PrintWarn(fmt.Sprintf("# %s 最近上报时间 %v", metricsTypeName, dateStr))
		}
	}

	if len(dateList) == 0 {
		PrintError("排查结果：无数据上报到ACOS collector，请检查应用的ArmsAgent是否正常！")
	}

	return true
}

func showUserMetricLogs(collectorPodName string, userId string) {
	traceLogDir := "/root/logs/arms/tracelogs/" + userId
	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "arms-collector",
			Name:      collectorPodName,
		},
		Cmd: "ls -lh " + traceLogDir,
	}
	PrintInfo(fmt.Sprintf("从collector [ %s ]查询到用户[ %s ]的监控数据日志[ %s ]文件如下：", collectorPodName, userId, traceLogDir))
	output, _ := ckPodCmd.Init().ExecCommandInPod()
	fmt.Println(output)
}

// 获取指定应用最新的metrics日志
func getLatestMetricsLog(collectorPodName string, userId string, logFileName string, rpcType string, latestMetricLog string) string {
	cmd := "grep " + GlobalApp.AppId + " /root/logs/arms/tracelogs/" + userId + "/" + logFileName + " | grep -E '^" + rpcType + "\\|' | tail -n 1"
	var ckPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "arms-collector",
			Name:      collectorPodName,
		},
		Cmd: cmd,
	}
	metricsLogItem, err := ckPodCmd.Init().ExecCommandInPod()
	if err != nil {
		PrintError("查询日志失败" + err.Error())
	}
	if IsDebug {
		if metricsLogItem != "" {
			PrintSuccess(metricsLogItem)
		} else {
			PrintWarn(fmt.Sprintf("Pod %s 无匹配日志！", collectorPodName))
		}
	}
	if strings.Contains(metricsLogItem, "No such file or directory") {
		PrintWarn(fmt.Sprintf("Pod %s 无数据日志文件%s！", collectorPodName, logFileName))
		return latestMetricLog
	}

	latestMetricLog = latestMetricLog + "\n" + metricsLogItem
	if IsDebug {
		PrintInfo(fmt.Sprintf("Collector [%s] 的最新日志[%s]: \n%s", collectorPodName, logFileName, metricsLogItem))
	}
	return latestMetricLog
}
