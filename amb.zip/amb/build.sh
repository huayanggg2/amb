is_upload=$1

# >>>>>>>>>>>>>>>>>>>> color text tools
# Regular Colors
Black='\033[0;30m'        # Black
Red='\033[0;31m'          # Red
Green='\033[0;32m'        # Green
Yellow='\033[0;33m'       # Yellow
Blue='\033[0;34m'         # Blue
Purple='\033[0;35m'       # Purple
Cyan='\033[0;36m'         # Cyan
White='\033[0;37m'        # White
NC='\033[0m' # No Colo

print_color_text() {
  COLOR=$2
  TEXT=$1
  printf "${COLOR}${TEXT}${NC}"
}

text_info() {
  echo $(print_color_text "$1" $Cyan)
}

text_success() {
  echo $(print_color_text "$1" $Green)
}

text_error() {
  echo $(print_color_text "$1" $Red)
}

text_warn() {
  echo $(print_color_text "$1" $Yellow)
}
# color text tools <<<<<<<<<<<<<<<<<<<<<<

go_init() {
  go mod tidy
  go fmt .
}

set_build_args(){
  git_branch=`git rev-parse --abbrev-ref HEAD`
  date_str=`date +'%Y%m%d_%H%M%S'`
  version="$git_branch-$date_str"
  text_info "version: ${version}"
}

do_build_mac(){
  text_warn "building for mac..."
  go build -o ../amb-mac -ldflags "-X main.version=${version}" .
}

do_build_linux_amd() {
  text_warn "building for linux@amd64..."
  CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o ../amb-linux-x86_64 -ldflags "-X main.version=${version}" .
}

do_build_linux_arm() {
  text_warn "building for linux@arm64..."
  CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -o ../amb-linux-aarch64 -ldflags "-X main.version=${version}" .
}

do_build_linux() {
  do_build_linux_amd
  do_build_linux_arm
  # do_build_mac
}

do_build() {
  do_build_linux
}

show_result() {
  text_success "list bin files:"
  ls -l ../ | grep amb | awk '{print $NF}'
}

upload_to_oss() {
  echo "uploading x86_64 to oss ..."
  ossutil -f --acl public-read cp ../amb-linux-x86_64 oss://cnstack-service/amb/amb-linux-amd64
  echo "uploading aarch64 to oss ..."
  ossutil -f --acl public-read cp ../amb-linux-aarch64 oss://cnstack-service/amb/amb-linux-arm64
}

# >>>>>> main process
go_init
set_build_args
do_build
show_result

if [ "${is_upload}" == "true" ]; then
  upload_to_oss
fi