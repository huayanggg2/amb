# acos magic box

1. 功能：整合日常运维常用工具，提供acos数据监控链路全链路自助排查引导。
2. 对比：从python版本中移植而来，golang具备完全打包能力，不再需要在使用时依赖python及lib（有些客户现场无法安装），golang的bin文件构建后可以直接安装使用。

## 快速安装脚本
```shell
curl -q https://cnstack-service.oss-cn-hangzhou.aliyuncs.com/amb/install-amb.sh | sh
```

## 研发记录

1. 以CLI作为首选交互方式，使用cobra实现菜单树 
2. 静态文件需要用 *//go:embed* 声明，参考文件 *embed-file.go*
3. 打包可以使用build.sh文件，自动写入版本号，可以在mac上构建linux版本（默认只构建linux）

## TODO

1. 展示结果的美化输出效果 https://github.com/jedib0t/go-pretty
2. 确认/选择的交互：https://dev.to/tidalcloud/interactive-cli-prompts-in-go-3bj9 支持多选
3. 选择：https://github.com/manifoldco/promptui 不支持多选