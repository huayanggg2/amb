package flow

type ProcessDefinition struct {
	FlowNodes []*Node
}

type Variable struct {
	key   string
	value interface{}
}

// Node 流程中的每个节点
type Node struct {
	Id   string
	Name string
	Vars []*Variable
	Next string
}

// IProcess 参考activiti pvm
type IProcess interface {

	// Next 执行流程任务
	Next(act *Node) Node

	// AddVar 增加变量
	AddVar(key string, value interface{})

	// GetVar 获取变量
	GetVar(key string) interface{}
}
