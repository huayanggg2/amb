package clickhouse

import (
	. "acos-magic-box/common"
	"acos-magic-box/k8s"
	"acos-magic-box/replicate"
	"github.com/spf13/cobra"
	"os"
	"strconv"
	"strings"
	"time"
)

var rcNum int

// topic名称
var topicName string

// group名称
var groupName string

func init() {

	topicStatusCmd.PersistentFlags().StringVar(&topicName, "name", "", "topic name")
	topicStatusCmd.MarkPersistentFlagRequired("name")

	consumerGroupStatusCmd.PersistentFlags().StringVar(&groupName, "name", "dtsmart_group_ck", "group name")
	consumerGroupStatusCmd.MarkPersistentFlagRequired("name")

	replicaCmd.PersistentFlags().IntVar(&rcNum, "rcNum", 1, "replica number")
	replicaCmd.MarkPersistentFlagRequired("rcNum")

	kafkaRootCmd.AddCommand(entryPodCmd)
	kafkaRootCmd.AddCommand(listTopicsCmd)
	kafkaRootCmd.AddCommand(topicStatusCmd)
	kafkaRootCmd.AddCommand(listConsumerGroupsCmd)
	kafkaRootCmd.AddCommand(consumerGroupStatusCmd)
	kafkaRootCmd.AddCommand(replicaCmd)
}

// `echo 'ls /kafka/brokers/ids' | ./zkCli.sh  2>/dev/null | tail -n 2|head -n1|sed 's/\[//g'|sed 's/\]//g'|tr -d ' '`
var shellKafkaTopic = "/opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server=localhost:9092"

var entryPodCmd = &cobra.Command{
	Use:   "pod",
	Short: "进入Kafka的Pod交互模式",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		var podCmd = &k8s.AmbPodExec{
			Meta: &k8s.AmbPod{
				Namespace: "acos",
				Container: "kafka",
				Name:      "kafka-0",
			},
		}
		podCmd.Init().ExecCommand()
	},
}

var listTopicsCmd = &cobra.Command{
	Use:   "topics",
	Short: "列出来kafka的所有topic",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		script := shellKafkaTopic + " --list"
		execCmdInPod(script)
	},
}

var topicStatusCmd = &cobra.Command{
	Use:   "topic-status",
	Short: "查看Topic状态",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		script := shellKafkaTopic + " --describe --topic " + topicName
		execCmdInPod(script)
	},
}

var listConsumerGroupsCmd = &cobra.Command{
	Use:   "groups",
	Short: "列出来所有groups",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		script := "/opt/bitnami/kafka/bin/kafka-consumer-groups.sh --bootstrap-server=localhost:9092 --list"
		execCmdInPod(script)
	},
}

var consumerGroupStatusCmd = &cobra.Command{
	Use:   "group-status",
	Short: "查看Group下Topic消费状态",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		PrintInfo(`===== 字段解释 =====
GROUP：消费者所属的消费者组。
TOPIC：消费者正在消费的Topic名称。
PARTITION：分区号。
CURRENT-OFFSET：消费者当前已消费的消息偏移量。
LOG-END-OFFSET：消息分区中最后一条消息的偏移量。
LAG：当前分区的滞后数量，即尚未消费的消息数。
CONSUMER-ID：消费者ID。
HOST：消费者所在的主机名或IP地址。
CLIENT-ID：消费者客户端ID。`)

		if groupName == "" {
			// dtsmart_group_ck 是acos默认的group名称
			groupName = "dtsmart_group_ck"
		}

		script := "/opt/bitnami/kafka/bin/kafka-consumer-groups.sh --bootstrap-server=localhost:9092 --describe --group " + groupName
		execCmdInPod(script)
	},
}

func execCmdInPod(cmd string) {
	var podCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "kafka",
			Name:      "kafka-0",
		},
		PrintResult: true,
		Cmd:         cmd,
	}
	podCmd.Init().ExecCommandInPod()
}

func ExecZkCmdInPod() string {
	cmd := "echo 'ls /kafka/brokers/ids' | /apache-zookeeper-3.6.2-bin/bin/zkCli.sh  2>/dev/null | tail -n 2|head -n1|sed 's/\\[//g'|sed 's/\\]//g'|tr -d ' '"
	var podCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "zookeeper",
			Name:      "zk-clickhouse-0",
		},
		PrintResult: true,
		Cmd:         cmd,
	}
	output, err := podCmd.Init().ExecCommandInPod()
	if err != nil {
		panic(err)
	}
	return output
}

var replicaCmd = &cobra.Command{
	Use:   "rc",
	Short: "修改kafka副本数",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		if rcNum < 1 {
			PrintError("副本数不能小于1")
			os.Exit(0)
		}
		ap := os.Getenv("ACOS_PATH")
		resourceProfile := replicate.GetresourceProfile(ap + "/values.yaml")
		m := replicate.ReadYaml(ap + "/charts/kafka/values.yaml")
		currentReplicate := m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"].(int)
		m["resources"].(map[interface{}]interface{})[resourceProfile].(map[interface{}]interface{})["replicas"] = rcNum
		if rcNum > currentReplicate {
			PrintStep("进行扩容kafka操作！")
			replicate.WriteYaml(ap+"/charts/kafka/values.yaml", m)
			output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
			if err != nil {
				panic(err)
			} else {
				for {
					num, _ := ExecCommandAndOutput("kubectl get po -nacos|grep kafka|awk '{print $2,$3}'|uniq|wc -l")
					res, _ := strconv.Atoi(num)
					if res != 1 {
						PrintStep("waiting for pod running")
						time.Sleep(5 * time.Second)

					} else {
						break
					}
				}
				brokers := ExecZkCmdInPod()
				RebalanceFromKfa(brokers)
			}
			PrintInfo(output)
		} else if rcNum < currentReplicate {
			PrintStep("进行缩容kafka操作！")
			brokers := ExecZkCmdInPod()
			bl := strings.Split(brokers, ",")
			fn := bl[:rcNum]
			newBrokers := strings.Join(fn, ",")
			RebalanceFromKfa(newBrokers)
			replicate.WriteYaml(ap+"/charts/kafka/values.yaml", m)
			output, err := ExecCommandAndOutput("helm upgrade -nacos acos " + ap)
			if err != nil {
				panic(err)
			}
			PrintInfo(output)
		} else {
			PrintError("输入有误！")
			os.Exit(0)
		}
	},
}

var recreateKafka = &cobra.Command{
	Use:   "recreate",
	Short: "全新重建kafka",
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
	Run: func(cmd *cobra.Command, args []string) {
		// 1. kafka缩零
		// 2. 删除kafka pvc
		// 3. 删除zookeeper的/kafka > deleteall /kafka
		// 4. kafka副本还原
		// 5. 重启jlogserver > jlogclickhouse > arms-collector
	},
}

func RebalanceFromKfa(brokers string) string {
	var files = []string{"main.sh", "autoRebalance.sh", "autoAssign.sh"}
	CopyFilesToPod("acos", "kafka-0", "kafka", "/opt/bitnami/kafka", files)

	cmd := "bash /opt/bitnami/kafka/main.sh " + brokers
	var kfkPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "kafka",
			Name:      "kafka-0",
		},
		Cmd: cmd,
	}
	kfkPodCmd.Init().ExecCommand()
	return ""
}

func AddPartFromKfa(rc int) string {
	var files = []string{"addPartitions.sh"}
	CopyFilesToPod("acos", "kafka-0", "kafka", "/opt/bitnami/kafka", files)

	cmd := "bash /opt/bitnami/kafka/addPartitions.sh " + strconv.Itoa(rc)
	var kfkPodCmd = &k8s.AmbPodExec{
		Meta: &k8s.AmbPod{
			Namespace: "acos",
			Container: "kafka",
			Name:      "kafka-0",
		},
		Cmd: cmd,
	}
	kfkPodCmd.Init().ExecCommand()
	return ""
}
