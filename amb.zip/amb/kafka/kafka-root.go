package clickhouse

import (
	"acos-magic-box/cmd"
	. "acos-magic-box/common"
	"github.com/spf13/cobra"
)

var kafkaRootCmd = &cobra.Command{
	Use:   "kafka",
	Short: "Kafka工具",
	Example: `
amb kafka pod // 进入kafka pod
amb kafka topics // 列出来所有topic
amb kafka groups // 列出来所有group
amb kafka group-status --name xxx // 展示指定group下topic的消费情况
amb kafka topic-status --name xxx // 展示topic详情
`,
	PreRun: func(cmd *cobra.Command, args []string) {
		SetCommonFlags(cmd)
	},
}

func init() {
	cmd.RootCmd.AddCommand(kafkaRootCmd)
}
