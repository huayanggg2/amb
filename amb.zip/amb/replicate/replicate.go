package replicate

import (
	"acos-magic-box/common"
	"gopkg.in/yaml.v2"
	"io/ioutil"
)

func ReadYaml(fpath string) map[interface{}]interface{} {
	data, err := ioutil.ReadFile(fpath)
	if err != nil {
		panic(err)
	}
	m := make(map[interface{}]interface{})
	err = yaml.Unmarshal(data, &m)
	if err != nil {
		panic(err)
	}
	return m
}

func WriteYaml(fpath string, m map[interface{}]interface{}) {
	out, err := yaml.Marshal(m)
	if err != nil {
		panic(err)
	}
	err = ioutil.WriteFile(fpath, out, 0644)
	if err != nil {
		panic(err)
	}
	common.PrintInfo("Successfully updated config.yaml")

}

func GetresourceProfile(fpath string) string {
	data, err := ioutil.ReadFile(fpath)
	if err != nil {
		panic(err)
	}
	m := make(map[interface{}]interface{})
	err = yaml.Unmarshal(data, &m)
	if err != nil {
		panic(err)
	}
	rp := m["global"].(map[interface{}]interface{})["resourceProfile"].(string)
	common.PrintInfo("resourceProfile is : " + rp)
	return rp
}
